// Neuro-Acoustic Audio Generator & FX using Native Web Audio API
// Scientific sound synthesis for ADHD: Brown Noise (calms racing thoughts) & Pink Noise (reading focus)

class NeuroAudioService {
  constructor() {
    this.audioCtx = null;
    this.noiseNode = null;
    this.noiseGainNode = null;
    this.isPlaying = false;
    this.currentNoiseType = 'brown'; // 'brown' | 'pink'
    this.volume = 0.25; // Default comfortable level
    this.sfxEnabled = true;
  }

  initContext() {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  createBrownNoiseBuffer(duration = 5) {
    if (!this.audioCtx) return null;
    const sampleRate = this.audioCtx.sampleRate;
    const bufferSize = sampleRate * duration;
    const buffer = this.audioCtx.createBuffer(2, bufferSize, sampleRate);

    for (let channel = 0; channel < 2; channel++) {
      const data = buffer.getChannelData(channel);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        // Brownian random walk
        data[i] = (lastOut + (0.02 * white)) / 1.02;
        lastOut = data[i];
        // Scale to pleasant warm rumble
        data[i] *= 3.2;
      }
    }
    return buffer;
  }

  createPinkNoiseBuffer(duration = 5) {
    if (!this.audioCtx) return null;
    const sampleRate = this.audioCtx.sampleRate;
    const bufferSize = sampleRate * duration;
    const buffer = this.audioCtx.createBuffer(2, bufferSize, sampleRate);

    for (let channel = 0; channel < 2; channel++) {
      const data = buffer.getChannelData(channel);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        // Paul Kellet's 7-pole filter
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.12;
        b6 = white * 0.115926;
      }
    }
    return buffer;
  }

  startNoise(type = this.currentNoiseType) {
    this.initContext();
    if (!this.audioCtx) return;

    this.stopNoise();
    this.currentNoiseType = type;

    const buffer = type === 'pink' 
      ? this.createPinkNoiseBuffer(5) 
      : this.createBrownNoiseBuffer(5);

    if (!buffer) return;

    this.noiseNode = this.audioCtx.createBufferSource();
    this.noiseNode.buffer = buffer;
    this.noiseNode.loop = true;

    // Filter to eliminate harsh highs (anti-fatigue neuro-acoustic filter)
    const filter = this.audioCtx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = type === 'pink' ? 2400 : 900;

    this.noiseGainNode = this.audioCtx.createGain();
    this.noiseGainNode.gain.setValueAtTime(0.001, this.audioCtx.currentTime);
    this.noiseGainNode.gain.exponentialRampToValueAtTime(
      Math.max(0.001, this.volume), 
      this.audioCtx.currentTime + 0.5
    );

    this.noiseNode.connect(filter);
    filter.connect(this.noiseGainNode);
    this.noiseGainNode.connect(this.audioCtx.destination);

    this.noiseNode.start();
    this.isPlaying = true;
  }

  stopNoise() {
    if (this.noiseNode) {
      try {
        if (this.noiseGainNode && this.audioCtx) {
          this.noiseGainNode.gain.setValueAtTime(this.noiseGainNode.gain.value, this.audioCtx.currentTime);
          this.noiseGainNode.gain.exponentialRampToValueAtTime(0.0001, this.audioCtx.currentTime + 0.3);
          setTimeout(() => {
            if (this.noiseNode) {
              this.noiseNode.stop();
              this.noiseNode.disconnect();
              this.noiseNode = null;
            }
          }, 350);
        } else {
          this.noiseNode.stop();
          this.noiseNode.disconnect();
          this.noiseNode = null;
        }
      } catch {
        this.noiseNode = null;
      }
    }
    this.isPlaying = false;
  }

  setNoiseType(type) {
    if (this.currentNoiseType !== type) {
      this.currentNoiseType = type;
      if (this.isPlaying) {
        this.startNoise(type);
      }
    }
  }

  setVolume(vol) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.noiseGainNode && this.audioCtx) {
      this.noiseGainNode.gain.cancelScheduledValues(this.audioCtx.currentTime);
      this.noiseGainNode.gain.setValueAtTime(this.volume, this.audioCtx.currentTime);
    }
  }

  // --- Dopaminergic Neuro-Synthesized Sound Effects ---
  // Designed scientifically to avoid cortisol spikes and rejection sensitive dysphoria (RSD)

  playCorrectSound() {
    if (!this.sfxEnabled) return;
    this.initContext();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    // Harmonic two-tone chord (E5 to B5) - Emerald dopamine reward
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc1.type = 'sine';
    osc2.type = 'sine';

    osc1.frequency.setValueAtTime(659.25, now); // E5
    osc2.frequency.setValueAtTime(987.77, now + 0.08); // B5

    gainNode.gain.setValueAtTime(0.12, now);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);

    osc1.connect(gainNode);
    osc2.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now + 0.08);
    osc1.stop(now + 0.45);
    osc2.stop(now + 0.45);
  }

  playIncorrectSound() {
    if (!this.sfxEnabled) return;
    this.initContext();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    // Soft warm marimba wood tone (220Hz - A3). Zero jarring buzzer, zero cortisol!
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(175, now + 0.25);

    gainNode.gain.setValueAtTime(0.08, now);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.25);

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.25);
  }

  playTimerEndSound() {
    if (!this.sfxEnabled) return;
    this.initContext();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    const now = ctx.currentTime;

    // Gentle singing bowl harmonic triad
    [440, 554.37, 659.25].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.12);

      gainNode.gain.setValueAtTime(0.09, now + i * 0.12);
      gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 1.2);

      osc.connect(gainNode);
      gainNode.connect(ctx.destination);

      osc.start(now + i * 0.12);
      osc.stop(now + 1.2);
    });
  }

  playCompletionCelebration() {
    if (!this.sfxEnabled) return;
    this.initContext();
    if (!this.audioCtx) return;

    const ctx = this.audioCtx;
    const now = ctx.currentTime;
    // Ascending celebratory major arpeggio
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.09);

      gain.gain.setValueAtTime(0.1, now + idx * 0.09);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.09 + 0.6);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + idx * 0.09);
      osc.stop(now + idx * 0.09 + 0.6);
    });
  }
}

export const neuroAudio = new NeuroAudioService();
