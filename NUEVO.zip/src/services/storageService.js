import {
  INITIAL_TOPICS,
  INITIAL_FLASHCARDS,
  INITIAL_EXAM_QUESTIONS,
  INITIAL_DISTRACTIONS,
} from '../data/initialData';

const STORAGE_KEYS = {
  TOPICS: 'opocnp_topics_v1',
  FLASHCARDS: 'opocnp_flashcards_v1',
  EXAM_QUESTIONS: 'opocnp_exam_questions_v1',
  EXAM_HISTORY: 'opocnp_exam_history_v1',
  DISTRACTIONS: 'opocnp_distractions_v1',
  STREAK: 'opocnp_streak_v1',
  SETTINGS: 'opocnp_settings_v1',
};

// Safe JSON parser
function safeGet(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.error(`Error loading ${key} from localStorage`, e);
    return fallback;
  }
}

function safeSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Error saving ${key} to localStorage`, e);
  }
}

export const StorageService = {
  // Topics
  getTopics() {
    return safeGet(STORAGE_KEYS.TOPICS, INITIAL_TOPICS);
  },
  saveTopics(topics) {
    safeSet(STORAGE_KEYS.TOPICS, topics);
  },
  addTopic(newTopic) {
    const topics = this.getTopics();
    const updated = [newTopic, ...topics];
    this.saveTopics(updated);
    return updated;
  },

  // Flashcards
  getFlashcards() {
    return safeGet(STORAGE_KEYS.FLASHCARDS, INITIAL_FLASHCARDS);
  },
  saveFlashcards(flashcards) {
    safeSet(STORAGE_KEYS.FLASHCARDS, flashcards);
  },
  updateFlashcardStatus(cardId, newStatus) {
    const cards = this.getFlashcards();
    const updated = cards.map(c => {
      if (c.id === cardId) {
        return {
          ...c,
          status: newStatus,
          reviews: (c.reviews || 0) + 1,
          lastReviewed: new Date().toISOString()
        };
      }
      return c;
    });
    this.saveFlashcards(updated);
    return updated;
  },
  addFlashcards(newCards) {
    const existing = this.getFlashcards();
    const updated = [...newCards, ...existing];
    this.saveFlashcards(updated);
    return updated;
  },

  // Exam Questions
  getExamQuestions() {
    return safeGet(STORAGE_KEYS.EXAM_QUESTIONS, INITIAL_EXAM_QUESTIONS);
  },
  saveExamQuestions(questions) {
    safeSet(STORAGE_KEYS.EXAM_QUESTIONS, questions);
  },
  addExamQuestions(newQuestions) {
    const existing = this.getExamQuestions();
    const updated = [...newQuestions, ...existing];
    this.saveExamQuestions(updated);
    return updated;
  },

  // Exam History
  getExamHistory() {
    return safeGet(STORAGE_KEYS.EXAM_HISTORY, []);
  },
  saveExamResult(result) {
    const history = this.getExamHistory();
    const updated = [result, ...history];
    safeSet(STORAGE_KEYS.EXAM_HISTORY, updated);
    this.recordStudyActivity(result.totalQuestions * 1.5); // approximate minutes
    return updated;
  },

  // Distractions (Brain Dump)
  getDistractions() {
    return safeGet(STORAGE_KEYS.DISTRACTIONS, INITIAL_DISTRACTIONS);
  },
  saveDistractions(list) {
    safeSet(STORAGE_KEYS.DISTRACTIONS, list);
  },
  addDistraction(text) {
    const list = this.getDistractions();
    const newItem = {
      id: 'dist-' + Date.now(),
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      completed: false
    };
    const updated = [newItem, ...list];
    this.saveDistractions(updated);
    return updated;
  },
  toggleDistraction(id) {
    const list = this.getDistractions();
    const updated = list.map(item => item.id === id ? { ...item, completed: !item.completed } : item);
    this.saveDistractions(updated);
    return updated;
  },
  deleteDistraction(id) {
    const list = this.getDistractions();
    const updated = list.filter(item => item.id !== id);
    this.saveDistractions(updated);
    return updated;
  },
  clearCompletedDistractions() {
    const list = this.getDistractions();
    const updated = list.filter(item => !item.completed);
    this.saveDistractions(updated);
    return updated;
  },

  // Streak & Study stats
  getStreak() {
    const today = new Date().toISOString().slice(0, 10);
    const fallback = {
      currentStreak: 1,
      lastDate: today,
      minutesToday: 25,
      totalSessions: 1
    };
    const streak = safeGet(STORAGE_KEYS.STREAK, fallback);

    // Calculate if streak is broken or continues
    const lastDate = streak.lastDate;
    if (lastDate !== today) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
      if (lastDate === yesterday) {
        // Keep current streak, reset minutesToday
        streak.minutesToday = 0;
      } else {
        // Broken streak
        streak.currentStreak = 1;
        streak.minutesToday = 0;
      }
      streak.lastDate = today;
      safeSet(STORAGE_KEYS.STREAK, streak);
    }
    return streak;
  },
  recordStudyActivity(addedMinutes = 5) {
    const streak = this.getStreak();
    streak.minutesToday = Math.round((streak.minutesToday || 0) + addedMinutes);
    streak.totalSessions = (streak.totalSessions || 0) + 1;
    safeSet(STORAGE_KEYS.STREAK, streak);
    return streak;
  },

  // Settings & API Key
  getSettings() {
    return safeGet(STORAGE_KEYS.SETTINGS, {
      geminiApiKey: '',
      soundEnabled: true,
      instantFeedbackDefault: true,
      audioNoiseVolume: 0.25,
      noiseType: 'brown',
    });
  },
  saveSettings(settings) {
    safeSet(STORAGE_KEYS.SETTINGS, settings);
  },

  // Reset to original demo data
  resetAll() {
    localStorage.removeItem(STORAGE_KEYS.TOPICS);
    localStorage.removeItem(STORAGE_KEYS.FLASHCARDS);
    localStorage.removeItem(STORAGE_KEYS.EXAM_QUESTIONS);
    localStorage.removeItem(STORAGE_KEYS.EXAM_HISTORY);
    localStorage.removeItem(STORAGE_KEYS.DISTRACTIONS);
    localStorage.removeItem(STORAGE_KEYS.STREAK);
    window.location.reload();
  }
};
