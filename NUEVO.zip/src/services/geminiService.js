// Service to interact with Google Gemini 2.5 Flash API with PDF/Image inlineData
// Formatted strictly for Spanish CNP Police opposition syllabi with ADHD mnemonic hooks

export async function processSyllabusWithGemini({
  fileBase64,
  mimeType,
  complementaryText = '',
  apiKey,
}) {
  if (!apiKey || apiKey.trim() === '') {
    throw new Error('Debes configurar tu API Key de Gemini en los ajustes o en el panel de subida.');
  }

  const cleanKey = apiKey.trim();
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${cleanKey}`;

  const promptSystem = `
Eres un preparador de élite de oposiciones para el Cuerpo Nacional de Policía (CNP) de España y un especialista en técnicas de memorización para personas con TDAH y neurodivergentes.
Tu tarea es analizar el documento adjunto (PDF, imagen o apuntes) y el texto complementario facilitado, y generar EXCLUSIVAMENTE a partir de este contenido:

1. Un mazo de FLASHCARDS DE ALTO RENDIMIENTO (mínimo 6-10 tarjetas clave).
   - "question": Pregunta directa y clara sobre un artículo, plazo, definición, órgano o competencia.
   - "answer": Respuesta concisa, precisa y jurídicamente exacta según el texto aportado.
   - "mnemonicClue": Pista mnemotécnica potente, acrónimo (ej. "NIL", "COP"), analogía visual o truco mental para fijar la información sin esfuerzo en un cerebro TDAH.
   - "reference": Artículo o referencia exacta del documento (ej. "Art. 15 CE", "Art. 5.2 LO 2/1986").

2. Un banco de PREGUNTAS TIPO TEST OFICIALES CNP (mínimo 8-15 preguntas).
   - "question": Pregunta redactada con el rigor y las trampas habituales de los tribunales oficiales del CNP.
   - "options": EXACTAMENTE 3 opciones (formato oficial CNP: A, B y C). Solo una opción es la verdadera o jurídicamente correcta.
   - "correctIndex": Índice numérico de la opción correcta (0 para A, 1 para B, 2 para C).
   - "justification": Explicación detallada citando textualmente el motivo por el cual es correcta la opción elegida y por qué las otras son incorrectas, basándote en el documento adjunto.

REGLAS ESTRICTAS:
- NO busques ni inventes temario fuera del documento facilitado. Si el texto no menciona algo, no lo incluyas.
- Formato oficial CNP obligatorio: 3 opciones por pregunta (ni 4 ni 2).
- Devuelve ÚNICAMENTE un objeto JSON válido con la siguiente estructura:
{
  "topicTitle": "Título descriptivo del tema o ley tratada",
  "topicSummary": "Resumen ejecutivo en 2 líneas",
  "category": "Ciencias Jurídicas" | "Ciencias Sociales" | "Materias Técnico-Científicas",
  "flashcards": [
    {
      "question": "...",
      "answer": "...",
      "mnemonicClue": "...",
      "reference": "..."
    }
  ],
  "examQuestions": [
    {
      "question": "...",
      "options": ["A) ...", "B) ...", "C) ..."],
      "correctIndex": 0,
      "justification": "..."
    }
  ]
}
`.trim();

  // Prepare parts
  const parts = [];

  // Add inlineData if file is present
  if (fileBase64 && mimeType) {
    // Strip data URL header if present (e.g., data:application/pdf;base64,)
    const cleanBase64 = fileBase64.includes(',') 
      ? fileBase64.split(',')[1] 
      : fileBase64;

    parts.push({
      inlineData: {
        mimeType: mimeType,
        data: cleanBase64
      }
    });
  }

  // Add text instructions and user complementary text
  let fullUserPrompt = promptSystem;
  if (complementaryText && complementaryText.trim()) {
    fullUserPrompt += `\n\n[TEXTO COMPLEMENTARIO O APUNTES DEL OPOSITOR]:\n${complementaryText.trim()}`;
  }
  parts.push({ text: fullUserPrompt });

  const requestBody = {
    contents: [
      {
        role: "user",
        parts: parts
      }
    ],
    generationConfig: {
      temperature: 0.2, // Low temperature for high factual accuracy
      responseMimeType: "application/json",
    }
  };

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const msg = errorData?.error?.message || `Error del servidor HTTP ${response.status}: ${response.statusText}`;
      throw new Error(`Error en la API de Gemini: ${msg}`);
    }

    const data = await response.json();
    const candidateText = data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!candidateText) {
      throw new Error('La API de Gemini no devolvió contenido de texto.');
    }

    // Clean JSON markdown fences if any
    let cleanedJson = candidateText.trim();
    if (cleanedJson.startsWith('```json')) {
      cleanedJson = cleanedJson.replace(/^```json\s*/, '').replace(/\s*```$/, '');
    } else if (cleanedJson.startsWith('```')) {
      cleanedJson = cleanedJson.replace(/^```\s*/, '').replace(/\s*```$/, '');
    }

    const parsed = JSON.parse(cleanedJson);

    // Validate structure
    if (!parsed.flashcards || !Array.isArray(parsed.flashcards)) {
      parsed.flashcards = [];
    }
    if (!parsed.examQuestions || !Array.isArray(parsed.examQuestions)) {
      parsed.examQuestions = [];
    }

    // Assign IDs
    const topicId = 'topic-' + Date.now();
    parsed.id = topicId;
    parsed.flashcards = parsed.flashcards.map((fc, idx) => ({
      ...fc,
      id: `fc-gen-${Date.now()}-${idx}`,
      topicId: topicId,
      status: 'new',
      reviews: 0,
      lastReviewed: null
    }));

    parsed.examQuestions = parsed.examQuestions.map((eq, idx) => ({
      ...eq,
      id: `eq-gen-${Date.now()}-${idx}`,
      topicId: topicId,
      correctIndex: typeof eq.correctIndex === 'number' ? eq.correctIndex : 0
    }));

    return parsed;

  } catch (err) {
    console.error('Gemini processing error:', err);
    throw err;
  }
}
