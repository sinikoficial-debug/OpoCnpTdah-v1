import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import PomodoroTimer from './components/PomodoroTimer';
import FlashcardsView from './components/FlashcardsView';
import ExamSimulatorView from './components/ExamSimulatorView';
import SyllabusUploaderView from './components/SyllabusUploaderView';
import DistractionParkingModal from './components/DistractionParkingModal';
import ApiKeyModal from './components/ApiKeyModal';

import { StorageService } from './services/storageService';
import { 
  FileCheck2, 
  Layers, 
  UploadCloud, 
  History, 
  Sparkles, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Award,
  BookOpen
} from 'lucide-react';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState('exam'); // 'exam' | 'flashcards' | 'syllabus' | 'history'
  const [zenMode, setZenMode] = useState(false);

  // Modals
  const [isDistractionsOpen, setIsDistractionsOpen] = useState(false);
  const [isApiKeyOpen, setIsApiKeyOpen] = useState(false);

  // Persistent States
  const [topics, setTopics] = useState([]);
  const [flashcards, setFlashcards] = useState([]);
  const [examQuestions, setExamQuestions] = useState([]);
  const [examHistory, setExamHistory] = useState([]);
  const [distractions, setDistractions] = useState([]);
  const [streak, setStreak] = useState({ currentStreak: 1, minutesToday: 0 });
  const [settings, setSettings] = useState({ geminiApiKey: '' });

  // Load from Storage on mount
  useEffect(() => {
    setTopics(StorageService.getTopics());
    setFlashcards(StorageService.getFlashcards());
    setExamQuestions(StorageService.getExamQuestions());
    setExamHistory(StorageService.getExamHistory());
    setDistractions(StorageService.getDistractions());
    setStreak(StorageService.getStreak());
    setSettings(StorageService.getSettings());
  }, []);

  // Handlers for Distraction Parking (Brain Dump)
  const handleAddDistraction = (text) => {
    const updated = StorageService.addDistraction(text);
    setDistractions(updated);
  };

  const handleToggleDistraction = (id) => {
    const updated = StorageService.toggleDistraction(id);
    setDistractions(updated);
  };

  const handleDeleteDistraction = (id) => {
    const updated = StorageService.deleteDistraction(id);
    setDistractions(updated);
  };

  const handleClearCompletedDistractions = () => {
    const updated = StorageService.clearCompletedDistractions();
    setDistractions(updated);
  };

  // Handlers for Flashcards SRS
  const handleUpdateFlashcardStatus = (cardId, status) => {
    const updated = StorageService.updateFlashcardStatus(cardId, status);
    setFlashcards(updated);
  };

  // Handlers for Exam results & error conversion
  const handleSaveExamResult = (result) => {
    const updated = StorageService.saveExamResult(result);
    setExamHistory(updated);
    setStreak(StorageService.getStreak());
  };

  const handleConvertMistakesToFlashcards = (newCards) => {
    const updated = StorageService.addFlashcards(newCards);
    setFlashcards(updated);
    // Increment flashcard count on relevant topics
    setTopics(prev => prev.map(t => {
      const addedForThisTopic = newCards.filter(c => c.topicId === t.id).length;
      return addedForThisTopic > 0 
        ? { ...t, flashcardCount: (t.flashcardCount || 0) + addedForThisTopic }
        : t;
    }));
  };

  // Handlers for AI Generated syllabus content
  const handleAddGeneratedContent = (parsed) => {
    // 1. Add topic
    const newTopic = {
      id: parsed.id,
      title: parsed.topicTitle || 'Tema Importado',
      category: parsed.category || 'Ciencias Jurídicas',
      description: parsed.topicSummary || 'Material generado a partir de documento propio.',
      createdAt: new Date().toISOString(),
      flashcardCount: parsed.flashcards.length,
      examQuestionCount: parsed.examQuestions.length
    };
    const updatedTopics = StorageService.addTopic(newTopic);
    setTopics(updatedTopics);

    // 2. Add flashcards
    if (parsed.flashcards.length > 0) {
      const updatedFC = StorageService.addFlashcards(parsed.flashcards);
      setFlashcards(updatedFC);
    }

    // 3. Add exam questions
    if (parsed.examQuestions.length > 0) {
      const updatedEQ = StorageService.addExamQuestions(parsed.examQuestions);
      setExamQuestions(updatedEQ);
    }
  };

  // Handlers for Settings & API Key
  const handleSaveApiKey = (key) => {
    const newSettings = { ...settings, geminiApiKey: key };
    StorageService.saveSettings(newSettings);
    setSettings(newSettings);
  };

  const handleResetData = () => {
    StorageService.resetAll();
  };

  return (
    <div className="min-h-screen bg-[#0B1120] text-[#F1F5F9] flex flex-col font-sans">
      {/* Header with Neuro-Audio generator & Mode toggles */}
      <Header
        zenMode={zenMode}
        setZenMode={setZenMode}
        onOpenDistractions={() => setIsDistractionsOpen(true)}
        distractionsCount={distractions.filter(d => !d.completed).length}
        onOpenApiKey={() => setIsApiKeyOpen(true)}
        hasApiKey={Boolean(settings.geminiApiKey)}
        streak={streak}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Pomodoro Timer (Always present, optimized for ADHD Flow) */}
        <section aria-label="Pomodoro TDAH">
          <PomodoroTimer
            onStudyTick={(mins) => {
              const updated = StorageService.recordStudyActivity(mins);
              setStreak(updated);
            }}
            onQuickPark={handleAddDistraction}
          />
        </section>

        {/* Secondary Navigation (Hidden in Zen Mode to prevent distraction overload) */}
        {!zenMode && (
          <nav className="flex items-center justify-between border-b border-[#233252]/80 pb-1 overflow-x-auto gap-2">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <button
                onClick={() => setActiveTab('exam')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all whitespace-nowrap ${
                  activeTab === 'exam'
                    ? 'bg-emerald-500/15 border border-emerald-500/50 text-emerald-300 shadow-sm shadow-emerald-500/10'
                    : 'text-bone-400 hover:text-bone-200 hover:bg-[#131C31]'
                }`}
              >
                <FileCheck2 className="w-4 h-4 text-emerald-400" />
                <span>Simulador CNP</span>
              </button>

              <button
                onClick={() => setActiveTab('flashcards')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all whitespace-nowrap ${
                  activeTab === 'flashcards'
                    ? 'bg-emerald-500/15 border border-emerald-500/50 text-emerald-300 shadow-sm shadow-emerald-500/10'
                    : 'text-bone-400 hover:text-bone-200 hover:bg-[#131C31]'
                }`}
              >
                <Layers className="w-4 h-4 text-emerald-400" />
                <span>Flashcards SRS ({flashcards.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('syllabus')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all whitespace-nowrap ${
                  activeTab === 'syllabus'
                    ? 'bg-emerald-500/15 border border-emerald-500/50 text-emerald-300 shadow-sm shadow-emerald-500/10'
                    : 'text-bone-400 hover:text-bone-200 hover:bg-[#131C31]'
                }`}
              >
                <UploadCloud className="w-4 h-4 text-emerald-400" />
                <span>Subir Temario + IA</span>
              </button>

              <button
                onClick={() => setActiveTab('history')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all whitespace-nowrap ${
                  activeTab === 'history'
                    ? 'bg-emerald-500/15 border border-emerald-500/50 text-emerald-300 shadow-sm shadow-emerald-500/10'
                    : 'text-bone-400 hover:text-bone-200 hover:bg-[#131C31]'
                }`}
              >
                <History className="w-4 h-4 text-emerald-400" />
                <span>Historial</span>
              </button>
            </div>
          </nav>
        )}

        {/* Content View Switcher */}
        <section aria-label="Módulo Activo">
          {activeTab === 'exam' && (
            <ExamSimulatorView
              examQuestions={examQuestions}
              topics={topics}
              onSaveResult={handleSaveExamResult}
              onConvertMistakesToFlashcards={handleConvertMistakesToFlashcards}
            />
          )}

          {activeTab === 'flashcards' && (
            <FlashcardsView
              flashcards={flashcards}
              topics={topics}
              onUpdateStatus={handleUpdateFlashcardStatus}
            />
          )}

          {activeTab === 'syllabus' && (
            <SyllabusUploaderView
              topics={topics}
              onAddGeneratedContent={handleAddGeneratedContent}
              onOpenApiKeyModal={() => setIsApiKeyOpen(true)}
              apiKey={settings.geminiApiKey}
            />
          )}

          {activeTab === 'history' && (
            <div className="max-w-3xl mx-auto space-y-4 animate-fade-in">
              <div className="bg-[#131C31] border border-[#233252] rounded-2xl p-6 shadow-xl">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
                      <History className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-bone-100">Historial de Simulacros CNP</h3>
                      <p className="text-xs text-bone-400">Evolución de tus notas con la fórmula oficial [Aciertos - Errores/2]</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono text-emerald-400 font-bold">
                    {examHistory.length} realizados
                  </span>
                </div>

                {examHistory.length === 0 ? (
                  <div className="text-center py-8 text-bone-500 text-xs">
                    <FileCheck2 className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    Todavía no has realizado ningún simulacro. Ve a la pestaña de simulador para hacer el primero.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {examHistory.map((item) => (
                      <div
                        key={item.id}
                        className="p-4 rounded-xl bg-[#0B1120] border border-[#233252] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
                      >
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-bold text-bone-200">Simulacro de {item.totalQuestions} preguntas</span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              item.isApto 
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
                                : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            }`}>
                              {item.isApto ? 'APTO' : 'NO APTO'}
                            </span>
                          </div>
                          <p className="text-[11px] text-bone-500 font-mono">{item.date}</p>
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="font-mono text-xs text-bone-300 flex items-center gap-2">
                            <span className="text-emerald-400 font-bold">+{item.rights}</span>
                            <span className="text-amber-400 font-bold">-{item.wrongs}</span>
                            <span className="text-bone-500">⚪{item.blanks}</span>
                          </div>
                          <div className={`font-mono text-xl font-black ${item.isApto ? 'text-emerald-400' : 'text-amber-400'}`}>
                            {item.score.toFixed(2)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </section>
      </main>

      {/* Brain Dump (Aparcar Pensamiento) Modal */}
      <DistractionParkingModal
        isOpen={isDistractionsOpen}
        onClose={() => setIsDistractionsOpen(false)}
        distractions={distractions}
        onAddDistraction={handleAddDistraction}
        onToggleDistraction={handleToggleDistraction}
        onDeleteDistraction={handleDeleteDistraction}
        onClearCompleted={handleClearCompletedDistractions}
      />

      {/* API Key Modal */}
      <ApiKeyModal
        isOpen={isApiKeyOpen}
        onClose={() => setIsApiKeyOpen(false)}
        apiKey={settings.geminiApiKey}
        onSaveApiKey={handleSaveApiKey}
        onResetData={handleResetData}
      />
    </div>
  );
}
