import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Plus, 
  Sparkles, 
  Coffee, 
  Zap, 
  Rocket, 
  Flame,
  CheckCircle2
} from 'lucide-react';
import { neuroAudio } from '../services/audioService';

const POMODORO_MODES = [
  {
    id: 'easy-start',
    label: 'Arranque Fácil',
    time: 10 * 60,
    badge: 'Vence parálisis',
    icon: Rocket,
    color: 'emerald',
    description: '10 min sin presión. Solo empezar ya es un triunfo.'
  },
  {
    id: 'adhd-focus',
    label: 'Foco TDAH',
    time: 25 * 60,
    badge: 'Estándar',
    icon: Zap,
    color: 'emerald',
    description: 'Bloque ideal de atención sostenida sin fatiga.'
  },
  {
    id: 'hyperfocus',
    label: 'Hiperfoco',
    time: 45 * 60,
    badge: 'Flujo Profundo',
    icon: Flame,
    color: 'amber',
    description: 'Para cuando estás 100% inmerso en un tema.'
  },
  {
    id: 'break',
    label: 'Descanso',
    time: 5 * 60,
    badge: 'Recarga',
    icon: Coffee,
    color: 'blue',
    description: 'Ponte de pie, bebe agua y estira la espalda.'
  }
];

export default function PomodoroTimer({ onStudyTick, onQuickPark }) {
  const [activeMode, setActiveMode] = useState('easy-start');
  const [timeLeft, setTimeLeft] = useState(10 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [quickThought, setQuickThought] = useState('');
  const [showThoughtSaved, setShowThoughtSaved] = useState(false);

  // Reference for interval
  const timerRef = useRef(null);

  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current);
            setIsRunning(false);
            neuroAudio.playTimerEndSound();
            if (activeMode !== 'break' && onStudyTick) {
              onStudyTick(5);
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }

    return () => clearInterval(timerRef.current);
  }, [isRunning, activeMode, onStudyTick]);

  const selectMode = (mode) => {
    setActiveMode(mode.id);
    setTimeLeft(mode.time);
    setIsRunning(false);
  };

  const togglePlayPause = () => {
    neuroAudio.initContext();
    setIsRunning(!isRunning);
  };

  const handleReset = () => {
    setIsRunning(false);
    const mode = POMODORO_MODES.find(m => m.id === activeMode);
    setTimeLeft(mode ? mode.time : 25 * 60);
  };

  // Add 5 minutes on the fly (flow state protection!)
  const handleAdd5Minutes = () => {
    setTimeLeft((prev) => prev + 300);
    // Visual feedback
  };

  // Quick brain dump submission
  const handleParkThought = (e) => {
    e.preventDefault();
    if (!quickThought.trim()) return;
    if (onQuickPark) {
      onQuickPark(quickThought.trim());
      setQuickThought('');
      setShowThoughtSaved(true);
      setTimeout(() => setShowThoughtSaved(false), 2200);
    }
  };

  // Format MM:SS
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  // Progress percentage
  const currentTotal = (POMODORO_MODES.find(m => m.id === activeMode) || POMODORO_MODES[0]).time;
  const progressPercent = Math.min(100, Math.max(0, ((currentTotal - timeLeft) / currentTotal) * 100));

  return (
    <div className="bg-[#131C31] border border-[#233252] rounded-2xl p-4 sm:p-5 shadow-xl transition-all">
      {/* Top Mode Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
        {POMODORO_MODES.map((mode) => {
          const Icon = mode.icon;
          const isSelected = activeMode === mode.id;
          return (
            <button
              key={mode.id}
              onClick={() => selectMode(mode)}
              className={`flex flex-col items-center justify-center p-2.5 rounded-xl border transition-all text-center relative overflow-hidden ${
                isSelected
                  ? 'bg-emerald-500/15 border-emerald-500/50 text-bone-100 shadow-md shadow-emerald-500/10'
                  : 'bg-[#1A253F]/40 border-[#233252]/60 text-bone-400 hover:text-bone-200 hover:bg-[#1A253F]'
              }`}
            >
              <div className="flex items-center gap-1.5 mb-1">
                <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-emerald-400' : 'text-bone-400'}`} />
                <span className="text-xs font-semibold">{mode.label}</span>
              </div>
              <span className={`text-[10px] px-1.5 py-0.2 rounded font-medium ${
                isSelected ? 'bg-emerald-500/25 text-emerald-300' : 'bg-[#233252]/50 text-bone-400'
              }`}>
                {mode.badge}
              </span>
            </button>
          );
        })}
      </div>

      {/* Main Timer Display & Flow Controls */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 py-2 border-y border-[#233252]/60 my-2">
        {/* Large Time Indicator */}
        <div className="flex items-baseline gap-3">
          <div className="font-mono text-4xl sm:text-5xl font-black tracking-tight text-bone-100">
            {formattedTime}
          </div>
          <div className="text-xs text-bone-400 font-medium hidden sm:block">
            {isRunning ? (
              <span className="text-emerald-400 flex items-center gap-1.5 animate-pulse">
                <span className="h-2 w-2 rounded-full bg-emerald-400"></span>
                Enfoque activo
              </span>
            ) : (
              <span>En pausa</span>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Play / Pause */}
          <button
            onClick={togglePlayPause}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm transition-all shadow-md ${
              isRunning
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 hover:bg-amber-500/30'
                : 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 shadow-emerald-500/20'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>Pausar</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Comenzar</span>
              </>
            )}
          </button>

          {/* Reset */}
          <button
            onClick={handleReset}
            title="Reiniciar contador"
            className="p-2.5 rounded-xl bg-[#1A253F] border border-[#233252] text-bone-400 hover:text-bone-200 hover:border-[#32456C] transition-all"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* +5m Button (Flow State Shield) */}
          <button
            onClick={handleAdd5Minutes}
            title="¿Estás en racha o hiperfoco? Añade 5 minutos sin romper tu concentración."
            className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/20 transition-all text-xs font-semibold"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400" />
            <span>+5 min</span>
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-[#1A253F] h-1.5 rounded-full overflow-hidden mt-2">
        <div 
          className="bg-gradient-to-r from-emerald-500 to-emerald-400 h-full transition-all duration-1000 ease-linear rounded-full"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Quick "Aparcar Distracción" Input (Brain Dump 2-Second Deposit) */}
      <div className="mt-4 pt-3 border-t border-[#233252]/60">
        <form onSubmit={handleParkThought} className="flex items-center gap-2">
          <input
            type="text"
            value={quickThought}
            onChange={(e) => setQuickThought(e.target.value)}
            placeholder="🧠 ¿Pensamiento intrusivo? Anótalo aquí en 2s y sigue estudiando..."
            className="flex-1 bg-[#0B1120] border border-[#233252] rounded-xl px-3.5 py-2 text-xs text-bone-100 placeholder-bone-500 focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/30 transition-all outline-none"
          />
          <button
            type="submit"
            disabled={!quickThought.trim()}
            className="px-3.5 py-2 rounded-xl bg-[#1A253F] hover:bg-[#233252] disabled:opacity-40 disabled:cursor-not-allowed border border-[#233252] text-amber-300 text-xs font-semibold transition-all whitespace-nowrap"
          >
            Aparcar
          </button>
        </form>

        {showThoughtSaved && (
          <div className="mt-2 flex items-center gap-1.5 text-xs text-emerald-400 animate-fade-in font-medium">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Pensamiento guardado a salvo. Memoria de trabajo despejada.</span>
          </div>
        )}
      </div>
    </div>
  );
}
