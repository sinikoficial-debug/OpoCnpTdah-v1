import React, { useState, useRef } from 'react';
import { 
  Upload, 
  FileText, 
  Image as ImageIcon, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  Key, 
  Trash2, 
  FileCheck,
  FolderOpen,
  ArrowRight,
  BookOpen
} from 'lucide-react';
import { processSyllabusWithGemini } from '../services/geminiService';
import { neuroAudio } from '../services/audioService';

export default function SyllabusUploaderView({
  topics,
  onAddGeneratedContent,
  onOpenApiKeyModal,
  apiKey,
}) {
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileBase64, setFileBase64] = useState('');
  const [filePreview, setFilePreview] = useState('');
  const [fileType, setFileType] = useState('');
  const [complementaryText, setComplementaryText] = useState('');
  const [customTitle, setCustomTitle] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processStep, setProcessStep] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successResult, setSuccessResult] = useState(null);

  const fileInputRef = useRef(null);

  // Handle file select
  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMessage('');
    setSelectedFile(file);
    setFileType(file.type);

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result;
      setFileBase64(result);
      if (file.type.startsWith('image/')) {
        setFilePreview(result);
      } else {
        setFilePreview('');
      }
    };
    reader.readAsDataURL(file);
  };

  const clearSelectedFile = () => {
    setSelectedFile(null);
    setFileBase64('');
    setFilePreview('');
    setFileType('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Submit to Gemini API
  const handleGenerate = async (e) => {
    e.preventDefault();
    if (!fileBase64 && !complementaryText.trim()) {
      setErrorMessage('Por favor, adjunta un archivo PDF/imagen o escribe el texto de tu temario.');
      return;
    }

    if (!apiKey) {
      onOpenApiKeyModal();
      return;
    }

    setIsProcessing(true);
    setErrorMessage('');
    setSuccessResult(null);

    try {
      setProcessStep('Subiendo material a Gemini 2.5 Flash...');
      await new Promise(r => setTimeout(r, 600));

      setProcessStep('Analizando articulado y conceptos clave sin buscar en la web...');
      await new Promise(r => setTimeout(r, 600));

      setProcessStep('Diseñando reglas mnemotécnicas TDAH y formato oficial CNP (A, B, C)...');

      const result = await processSyllabusWithGemini({
        fileBase64,
        mimeType: fileType || 'application/pdf',
        complementaryText,
        apiKey
      });

      if (customTitle.trim()) {
        result.topicTitle = customTitle.trim();
      }

      // Add to main storage
      onAddGeneratedContent(result);
      setSuccessResult(result);
      neuroAudio.playCompletionCelebration();

      // Clear form
      clearSelectedFile();
      setComplementaryText('');
      setCustomTitle('');

    } catch (err) {
      console.error(err);
      setErrorMessage(err.message || 'Error procesando el temario con Gemini.');
      neuroAudio.playIncorrectSound();
    } finally {
      setIsProcessing(false);
      setProcessStep('');
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      {/* Introduction Card */}
      <div className="bg-[#131C31] border border-[#233252] rounded-2xl p-6 shadow-xl">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
              <Upload className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-bone-100">
                Subida de Temario Propio + Extracción IA
              </h2>
              <p className="text-xs text-bone-400">
                La app NO busca en internet. Procesa estrictamente tus fotos de apuntes, esquemas o PDFs oficiales con Gemini 2.5 Flash.
              </p>
            </div>
          </div>

          <button
            onClick={onOpenApiKeyModal}
            className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-all ${
              apiKey
                ? 'bg-[#1A253F] border-[#233252] text-bone-300 hover:text-bone-100'
                : 'bg-amber-500/20 border-amber-500/40 text-amber-300 animate-pulse'
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            <span>{apiKey ? 'API Key Configurada' : 'Configurar API Key'}</span>
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleGenerate} className="space-y-4 pt-3 border-t border-[#233252]">
          {/* File Upload Zone */}
          <div>
            <label className="text-xs font-semibold text-bone-300 block mb-2">
              Adjuntar PDF o Fotos/Capturas de Apuntes:
            </label>

            {!selectedFile ? (
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-[#233252] hover:border-emerald-500/50 bg-[#0B1120]/60 rounded-2xl p-6 text-center cursor-pointer transition-all group"
              >
                <div className="w-12 h-12 rounded-xl bg-[#1A253F] border border-[#233252] flex items-center justify-center mx-auto mb-3 text-emerald-400 group-hover:scale-105 transition-transform">
                  <Upload className="w-6 h-6" />
                </div>
                <p className="text-xs font-semibold text-bone-200 mb-1">
                  Arrastra aquí o haz clic para seleccionar archivo
                </p>
                <p className="text-[11px] text-bone-500">
                  Admite archivos PDF, capturas de pantalla o imágenes (PNG, JPG, WEBP)
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="application/pdf,image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-[#0B1120] border border-emerald-500/40 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  {fileType.startsWith('image/') ? (
                    filePreview ? (
                      <img src={filePreview} alt="Preview" className="w-12 h-12 object-cover rounded-lg border border-[#233252]" />
                    ) : (
                      <ImageIcon className="w-8 h-8 text-emerald-400" />
                    )
                  ) : (
                    <FileText className="w-8 h-8 text-emerald-400" />
                  )}
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-bone-100 truncate">{selectedFile.name}</p>
                    <p className="text-[11px] text-bone-500 font-mono">
                      {(selectedFile.size / 1024).toFixed(1)} KB • {fileType || 'Documento'}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={clearSelectedFile}
                  className="p-2 rounded-lg text-bone-400 hover:text-amber-400 hover:bg-[#1A253F] transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* Complementary Text Input */}
          <div>
            <label className="text-xs font-semibold text-bone-300 block mb-1.5">
              Texto complementario o artículos legales a procesar:
            </label>
            <textarea
              rows={4}
              value={complementaryText}
              onChange={(e) => setComplementaryText(e.target.value)}
              placeholder="Puedes pegar aquí el texto íntegro de una ley, artículos de la Constitución o tus propios resúmenes..."
              className="w-full bg-[#0B1120] border border-[#233252] rounded-xl p-3 text-xs text-bone-100 placeholder-bone-500 focus:border-emerald-500/60 focus:ring-1 focus:ring-emerald-500/30 outline-none leading-relaxed"
            />
          </div>

          {/* Optional Title */}
          <div>
            <label className="text-xs font-semibold text-bone-300 block mb-1.5">
              Título personalizado para este tema (Opcional):
            </label>
            <input
              type="text"
              value={customTitle}
              onChange={(e) => setCustomTitle(e.target.value)}
              placeholder="Ej: Tema 15: Régimen Disciplinario CNP"
              className="w-full bg-[#0B1120] border border-[#233252] rounded-xl px-3.5 py-2.5 text-xs text-bone-100 placeholder-bone-500 focus:border-emerald-500/60 outline-none"
            />
          </div>

          {/* Error display */}
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/40 text-amber-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Processing Indicator */}
          {isProcessing && (
            <div className="p-4 rounded-xl bg-[#0B1120] border border-emerald-500/50 space-y-2 animate-fade-in">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
                <span>{processStep}</span>
              </div>
              <p className="text-[11px] text-bone-400">
                Gemini 2.5 Flash está sintetizando reglas mnemotécnicas y preguntas tipo test A, B, C a partir de tu documento.
              </p>
            </div>
          )}

          {/* Success card */}
          {successResult && (
            <div className="p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/50 text-emerald-200 text-xs space-y-2 animate-fade-in">
              <div className="flex items-center gap-2 font-bold text-emerald-300">
                <CheckCircle2 className="w-4 h-4" />
                <span>¡Material de estudio generado con éxito!</span>
              </div>
              <p className="text-bone-300">
                Se han añadido <strong className="text-emerald-400 font-mono">+{successResult.flashcards.length} Flashcards</strong> con pistas mnemotécnicas y <strong className="text-emerald-400 font-mono">+{successResult.examQuestions.length} Preguntas Oficiales</strong> de examen al tema <em>"{successResult.topicTitle}"</em>.
              </p>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isProcessing}
            className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 font-extrabold text-xs transition-all shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>{isProcessing ? 'Procesando con Gemini...' : 'Generar Flashcards y Examen con Gemini'}</span>
          </button>
        </form>
      </div>

      {/* Existing Topics Overview */}
      <div className="bg-[#131C31] border border-[#233252] rounded-2xl p-6 shadow-xl">
        <h3 className="text-sm font-bold text-bone-100 mb-3 flex items-center gap-2">
          <FolderOpen className="w-4 h-4 text-emerald-400" />
          <span>Tus Temas Almacenados en Local ({topics.length})</span>
        </h3>

        <div className="space-y-2.5">
          {topics.map(topic => (
            <div
              key={topic.id}
              className="p-3.5 rounded-xl bg-[#0B1120]/70 border border-[#233252] flex items-center justify-between gap-3 text-xs"
            >
              <div>
                <h4 className="font-bold text-bone-200">{topic.title}</h4>
                <p className="text-[11px] text-bone-500 line-clamp-1">{topic.description || 'Temario oficial CNP'}</p>
              </div>
              <div className="flex items-center gap-2 font-mono text-[11px] text-bone-400 flex-shrink-0">
                <span className="px-2 py-0.5 rounded bg-[#1A253F] border border-[#233252] text-emerald-400">
                  {topic.flashcardCount || 8} flashcards
                </span>
                <span className="px-2 py-0.5 rounded bg-[#1A253F] border border-[#233252] text-amber-400">
                  {topic.examQuestionCount || 10} preguntas
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
