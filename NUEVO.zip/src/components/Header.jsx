import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  Volume2, 
  VolumeX, 
  Headphones, 
  Eye, 
  EyeOff, 
  Brain, 
  Flame, 
  Key, 
  SlidersHorizontal,
  ChevronDown,
  Sparkles
} from 'lucide-react';
import { neuroAudio } from '../services/audioService';

export default function Header({
  zenMode,
  setZenMode,
  onOpenDistractions,
  distractionsCount,
  onOpenApiKey,
  hasApiKey,
  streak,
}) {
  const [isPlayingNoise, setIsPlayingNoise] = useState(false);
  const [noiseType, setNoiseType] = useState('brown');
  const [volume, setVolume] = useState(0.25);
  const [showNoiseMenu, setShowNoiseMenu] = useState(false);

  // Sync state with audio service
  const handleToggleNoise = () => {
    if (isPlayingNoise) {
      neuroAudio.stopNoise();
      setIsPlayingNoise(false);
    } else {
      neuroAudio.startNoise(noiseType);
      setIsPlayingNoise(true);
    }
  };

  const handleNoiseTypeChange = (type) => {
    setNoiseType(type);
    neuroAudio.setNoiseType(type);
    if (!isPlayingNoise) {
      neuroAudio.startNoise(type);
      setIsPlayingNoise(true);
    }
  };

  const handleVolumeChange = (e) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    neuroAudio.setVolume(val);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0B1120]/95 backdrop-blur-md border-b border-[#233252]/60 px-4 lg:px-6 py-2.5 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Logo & Identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 to-blue-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-sm shadow-emerald-500/10">
            <Shield className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-wide text-bone-100 flex items-center gap-1.5">
                OPOCNP <span className="text-emerald-400">FOCUS</span>
              </span>
              <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                TDAH & CNP
              </span>
            </div>
            {!zenMode && (
              <p className="text-xs text-bone-500 hidden sm:block">
                Neuroergonomía aplicada a la Oposición de Policía Nacional
              </p>
            )}
          </div>
        </div>

        {/* Center / Right Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Neuro-Acoustic Audio Generator */}
          <div className="relative">
            <div className={`flex items-center rounded-xl border p-1 transition-colors ${
              isPlayingNoise 
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300' 
                : 'bg-[#131C31] border-[#233252] text-bone-300 hover:border-[#32456C]'
            }`}>
              <button
                onClick={handleToggleNoise}
                title={isPlayingNoise ? 'Pausar audio neuro-acústico' : 'Reproducir audio neuro-acústico'}
                className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all hover:bg-emerald-500/20"
              >
                <Headphones className={`w-4 h-4 ${isPlayingNoise ? 'animate-bounce text-emerald-400' : ''}`} />
                <span className="hidden md:inline">
                  {isPlayingNoise ? (noiseType === 'brown' ? 'Ruido Marrón' : 'Ruido Rosa') : 'Audio TDAH'}
                </span>
                {isPlayingNoise ? (
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                ) : null}
              </button>

              <button
                onClick={() => setShowNoiseMenu(!showNoiseMenu)}
                className="p-1 rounded-lg hover:bg-[#1A253F] text-bone-400 hover:text-bone-200"
                title="Configurar tipo de ruido y volumen"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Audio Dropdown Menu */}
            {showNoiseMenu && (
              <div className="absolute right-0 mt-2 w-64 p-3 rounded-xl bg-[#131C31] border border-[#233252] shadow-2xl z-50 text-xs">
                <div className="font-semibold text-bone-200 mb-2 flex items-center justify-between">
                  <span>Generador Neuro-Acústico</span>
                  <span className="text-[10px] text-bone-500">Web Audio API</span>
                </div>

                {/* Noise Type selector */}
                <div className="space-y-1.5 mb-3">
                  <button
                    onClick={() => handleNoiseTypeChange('brown')}
                    className={`w-full text-left p-2 rounded-lg flex items-center justify-between transition-all ${
                      noiseType === 'brown'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-[#1A253F]/60 text-bone-300 hover:bg-[#1A253F]'
                    }`}
                  >
                    <div>
                      <div className="font-medium">Ruido Marrón (Brown)</div>
                      <div className="text-[10px] text-bone-400">Calma hiperactividad y rumiación</div>
                    </div>
                    {noiseType === 'brown' && <Sparkles className="w-3.5 h-3.5 text-emerald-400" />}
                  </button>

                  <button
                    onClick={() => handleNoiseTypeChange('pink')}
                    className={`w-full text-left p-2 rounded-lg flex items-center justify-between transition-all ${
                      noiseType === 'pink'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-[#1A253F]/60 text-bone-300 hover:bg-[#1A253F]'
                    }`}
                  >
                    <div>
                      <div className="font-medium">Ruido Rosa (Pink)</div>
                      <div className="text-[10px] text-bone-400">Foco sostenido y lectura jurídica</div>
                    </div>
                    {noiseType === 'pink' && <Sparkles className="w-3.5 h-3.5 text-emerald-400" />}
                  </button>
                </div>

                {/* Volume slider */}
                <div className="pt-2 border-t border-[#233252]">
                  <div className="flex items-center justify-between text-bone-400 mb-1.5">
                    <span className="flex items-center gap-1">
                      {volume === 0 ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                      Volumen
                    </span>
                    <span className="font-mono text-[11px] text-bone-300">{Math.round(volume * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.02"
                    value={volume}
                    onChange={handleVolumeChange}
                    className="w-full accent-emerald-500 bg-[#1A253F] h-1.5 rounded-lg cursor-pointer"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Brain Dump (Aparcar Pensamiento) Button */}
          <button
            onClick={onOpenDistractions}
            title="Aparcar distracción o pensamiento intrusivo"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#131C31] border border-[#233252] text-bone-300 hover:text-bone-100 hover:border-amber-500/40 hover:bg-amber-500/10 transition-all text-xs font-medium"
          >
            <Brain className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Brain Dump</span>
            {distractionsCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono">
                {distractionsCount}
              </span>
            )}
          </button>

          {/* Modo Hiperfoco (Zen Mode) Toggle */}
          <button
            onClick={() => setZenMode(!zenMode)}
            title={zenMode ? 'Salir del Modo Hiperfoco' : 'Activar Modo Hiperfoco (Oculta barras secundarias)'}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
              zenMode
                ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md shadow-emerald-500/25 ring-2 ring-emerald-500/30'
                : 'bg-[#131C31] border-[#233252] text-bone-300 hover:text-emerald-300 hover:border-emerald-500/40'
            }`}
          >
            {zenMode ? (
              <>
                <EyeOff className="w-4 h-4 text-slate-950" />
                <span>Zen Activo</span>
              </>
            ) : (
              <>
                <Eye className="w-4 h-4 text-emerald-400" />
                <span className="hidden sm:inline">Hiperfoco</span>
              </>
            )}
          </button>

          {/* Streak indicator */}
          <div 
            title={`Racha actual: ${streak.currentStreak} días seguidos. ¡Mantén el hábito!`}
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-[#131C31] border border-[#233252] text-xs font-semibold text-amber-400"
          >
            <Flame className="w-4 h-4 text-amber-400 fill-amber-400/20" />
            <span>{streak.currentStreak}d</span>
          </div>

          {/* Settings / API Key */}
          <button
            onClick={onOpenApiKey}
            title="Ajustes y Gemini API Key"
            className={`p-2 rounded-xl border text-xs transition-all ${
              hasApiKey
                ? 'bg-[#131C31] border-[#233252] text-bone-400 hover:text-bone-200 hover:border-[#32456C]'
                : 'bg-amber-500/15 border-amber-500/40 text-amber-300 animate-pulse'
            }`}
          >
            <Key className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
