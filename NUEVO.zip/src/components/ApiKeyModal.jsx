import React, { useState } from 'react';
import { 
  X, 
  Key, 
  ExternalLink, 
  ShieldCheck, 
  RotateCcw, 
  Check, 
  AlertTriangle 
} from 'lucide-react';

export default function ApiKeyModal({
  isOpen,
  onClose,
  apiKey,
  onSaveApiKey,
  onResetData,
}) {
  const [inputVal, setInputVal] = useState(apiKey || '');
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSave = (e) => {
    e.preventDefault();
    onSaveApiKey(inputVal.trim());
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  const handleReset = () => {
    if (window.confirm('¿Seguro que deseas reiniciar todos los datos locales a su estado inicial de muestra? Se restablecerán temas, flashcards y exámenes.')) {
      onResetData();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div 
        className="w-full max-w-md bg-[#131C31] border border-[#233252] rounded-2xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#233252] flex items-center justify-between bg-[#10172A]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-bone-100">Configuración & Gemini API</h3>
              <p className="text-[11px] text-bone-400">Modelo: gemini-2.5-flash (ultrarrápido)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-bone-400 hover:text-bone-200 hover:bg-[#1A253F] transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          <form onSubmit={handleSave} className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-bone-200 block mb-1">
                Tu Google Gemini API Key:
              </label>
              <input
                type="password"
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full bg-[#0B1120] border border-[#233252] rounded-xl px-3.5 py-2.5 text-xs text-bone-100 placeholder-bone-500 focus:border-emerald-500/60 focus:ring-1 focus:ring-emerald-500/30 outline-none font-mono"
              />
            </div>

            <div className="flex items-center justify-between text-[11px] text-bone-400">
              <span className="flex items-center gap-1 text-emerald-400">
                <ShieldCheck className="w-3.5 h-3.5" /> Se guarda solo en tu navegador (localStorage)
              </span>
              <a
                href="https://aistudio.google.com/app/apikey"
                target="_blank"
                rel="noreferrer"
                className="text-emerald-400 hover:underline flex items-center gap-1"
              >
                <span>Obtener clave gratis</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs transition-all shadow-md shadow-emerald-500/20 flex items-center justify-center gap-1.5"
            >
              {savedSuccess ? (
                <>
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>¡Guardado correctamente!</span>
                </>
              ) : (
                <span>Guardar API Key</span>
              )}
            </button>
          </form>

          {/* Reset zone */}
          <div className="pt-4 border-t border-[#233252]/80 flex items-center justify-between">
            <div>
              <div className="text-xs font-semibold text-bone-300">Restablecer Datos Locales</div>
              <div className="text-[10px] text-bone-500">Recarga los temas y tests CNP por defecto</div>
            </div>
            <button
              type="button"
              onClick={handleReset}
              className="px-3 py-1.5 rounded-xl border border-amber-500/30 text-amber-400 hover:bg-amber-500/10 text-xs font-medium flex items-center gap-1.5 transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Restablecer</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
