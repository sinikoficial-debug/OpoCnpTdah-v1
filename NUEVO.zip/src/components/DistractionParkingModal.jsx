import React, { useState } from 'react';
import { 
  X, 
  Brain, 
  Check, 
  Trash2, 
  Plus, 
  Sparkles,
  CheckCircle2,
  ListTodo
} from 'lucide-react';

export default function DistractionParkingModal({
  isOpen,
  onClose,
  distractions,
  onAddDistraction,
  onToggleDistraction,
  onDeleteDistraction,
  onClearCompleted,
}) {
  const [newText, setNewText] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!newText.trim()) return;
    onAddDistraction(newText.trim());
    setNewText('');
  };

  const pendingCount = distractions.filter(d => !d.completed).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div 
        className="w-full max-w-lg bg-[#131C31] border border-[#233252] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#233252] flex items-center justify-between bg-[#10172A]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-400">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-bone-100 flex items-center gap-2">
                Parking de Distracciones
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  {pendingCount} pendientes
                </span>
              </h2>
              <p className="text-xs text-bone-400">
                Vacía tu memoria de trabajo (Brain Dump). Tu foco queda blindado.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-bone-400 hover:text-bone-200 hover:bg-[#1A253F] transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Add Input */}
        <div className="p-4 border-b border-[#233252] bg-[#131C31]">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <input
              type="text"
              value={newText}
              onChange={(e) => setNewText(e.target.value)}
              placeholder="¿Qué idea acaba de asaltar tu mente? Escríbela aquí..."
              autoFocus
              className="flex-1 bg-[#0B1120] border border-[#233252] rounded-xl px-3.5 py-2.5 text-xs text-bone-100 placeholder-bone-500 focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/30 outline-none"
            />
            <button
              type="submit"
              disabled={!newText.trim()}
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 text-xs font-bold transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Aparcar</span>
            </button>
          </form>
        </div>

        {/* Distraction List */}
        <div className="p-4 overflow-y-auto space-y-2 flex-1">
          {distractions.length === 0 ? (
            <div className="text-center py-8 text-bone-500">
              <Sparkles className="w-8 h-8 mx-auto mb-2 text-emerald-400/60" />
              <p className="text-xs font-medium text-bone-300">¡Memoria de trabajo completamente despejada!</p>
              <p className="text-[11px] text-bone-500 mt-1">Cualquier duda o tarea doméstica anótala aquí sin salir del temario.</p>
            </div>
          ) : (
            distractions.map((item) => (
              <div
                key={item.id}
                className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                  item.completed
                    ? 'bg-[#10172A]/40 border-[#233252]/40 opacity-50'
                    : 'bg-[#1A253F]/60 border-[#233252] hover:border-amber-500/30'
                }`}
              >
                <div className="flex items-center gap-3 flex-1 min-w-0 pr-2">
                  <button
                    onClick={() => onToggleDistraction(item.id)}
                    className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all ${
                      item.completed
                        ? 'bg-emerald-500 border-emerald-400 text-slate-950'
                        : 'border-[#32456C] hover:border-emerald-400 text-transparent'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </button>
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs ${item.completed ? 'line-through text-bone-500' : 'text-bone-200'}`}>
                      {item.text}
                    </p>
                    <span className="text-[10px] text-bone-500 font-mono">
                      {item.timestamp}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => onDeleteDistraction(item.id)}
                  title="Eliminar"
                  className="p-1.5 rounded-lg text-bone-500 hover:text-amber-400 hover:bg-amber-500/10 transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {distractions.some(d => d.completed) && (
          <div className="p-3 border-t border-[#233252] bg-[#10172A] flex justify-end">
            <button
              onClick={onClearCompleted}
              className="text-xs text-bone-400 hover:text-amber-300 transition-colors"
            >
              Limpiar tareas completadas
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
