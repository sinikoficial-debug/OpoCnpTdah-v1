import React, { useState, useMemo } from 'react';
import { 
  CheckCircle2, 
  HelpCircle, 
  AlertCircle, 
  ArrowRight, 
  ArrowLeft, 
  RotateCcw, 
  Sparkles, 
  Layers, 
  ToggleLeft, 
  ToggleRight, 
  Award, 
  FileCheck,
  PlusCircle,
  Clock,
  ShieldCheck,
  BookmarkPlus
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { neuroAudio } from '../services/audioService';

export default function ExamSimulatorView({
  examQuestions,
  topics,
  onSaveResult,
  onConvertMistakesToFlashcards,
}) {
  // Setup state
  const [examState, setExamState] = useState('config'); // 'config' | 'taking' | 'results'
  const [questionCount, setQuestionCount] = useState(10); // 10, 20, 30, 40, 50
  const [selectedTopicId, setSelectedTopicId] = useState('all');
  const [instantFeedback, setInstantFeedback] = useState(true);

  // Active exam state
  const [activeQuestions, setActiveQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState({}); // { [questionId]: selectedOptionIndex (0, 1, 2) }
  const [examResult, setExamResult] = useState(null);
  const [convertedFlashcardsDone, setConvertedFlashcardsDone] = useState(false);

  // Prepare questions pool
  const filteredPool = useMemo(() => {
    return examQuestions.filter(q => {
      if (selectedTopicId === 'all') return true;
      return q.topicId === selectedTopicId;
    });
  }, [examQuestions, selectedTopicId]);

  // Start exam
  const handleStartExam = () => {
    neuroAudio.initContext();
    // Shuffle and pick
    const shuffled = [...filteredPool].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, Math.min(questionCount, shuffled.length));

    if (selected.length === 0) {
      alert('No hay suficientes preguntas disponibles para este tema.');
      return;
    }

    setActiveQuestions(selected);
    setCurrentIndex(0);
    setAnswers({});
    setExamResult(null);
    setConvertedFlashcardsDone(false);
    setExamState('taking');
  };

  // Handle picking an answer
  const handleSelectOption = (questionId, optionIndex) => {
    // If feedback is already revealed in instant feedback mode, don't allow changing
    if (instantFeedback && answers[questionId] !== undefined) {
      return;
    }

    const currentQ = activeQuestions.find(q => q.id === questionId);
    const isCorrect = currentQ && currentQ.correctIndex === optionIndex;

    if (isCorrect) {
      neuroAudio.playCorrectSound();
    } else {
      neuroAudio.playIncorrectSound();
    }

    setAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex
    }));
  };

  // Clear answer (dejar en blanco)
  const handleClearAnswer = (questionId) => {
    setAnswers(prev => {
      const copy = { ...prev };
      delete copy[questionId];
      return copy;
    });
  };

  // Finalize exam and calculate official CNP score
  const handleFinishExam = () => {
    let rights = 0;
    let wrongs = 0;
    let blanks = 0;
    const mistakes = [];

    activeQuestions.forEach(q => {
      const ans = answers[q.id];
      if (ans === undefined) {
        blanks++;
      } else if (ans === q.correctIndex) {
        rights++;
      } else {
        wrongs++;
        mistakes.push({
          question: q.question,
          correctAnswer: q.options[q.correctIndex],
          userAnswer: q.options[ans],
          justification: q.justification,
          topicId: q.topicId
        });
      }
    });

    const total = activeQuestions.length;
    // Official CNP Formula: [Aciertos - (Errores / 2)] * (10 / Total)
    const rawScore = (rights - (wrongs / 2)) * (10 / total);
    const finalScore = Math.max(0, parseFloat(rawScore.toFixed(2)));
    const isApto = finalScore >= 5.0;

    const result = {
      id: 'res-' + Date.now(),
      date: new Date().toLocaleDateString('es-ES', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }),
      totalQuestions: total,
      rights,
      wrongs,
      blanks,
      score: finalScore,
      isApto,
      mistakes,
    };

    setExamResult(result);
    setExamState('results');
    onSaveResult(result);

    if (isApto) {
      neuroAudio.playCompletionCelebration();
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10B981', '#34D399', '#6EE7B7']
      });
    }
  };

  // Convert mistakes to flashcards
  const handleConvertMistakes = () => {
    if (!examResult || examResult.mistakes.length === 0) return;

    const newCards = examResult.mistakes.map((m, idx) => ({
      id: `fc-mistake-${Date.now()}-${idx}`,
      topicId: m.topicId || 'cnp-topic-1',
      question: m.question,
      answer: m.correctAnswer,
      mnemonicClue: `Atención al fallo: ${m.justification}`,
      reference: 'Repaso de Examen CNP (Fallo corregido)',
      status: 'hard', // starts in Hard review
      reviews: 0,
      lastReviewed: null
    }));

    onConvertMistakesToFlashcards(newCards);
    setConvertedFlashcardsDone(true);
    neuroAudio.playCorrectSound();
  };

  // Chunking calculation: 10 questions per chunk
  const totalChunks = Math.ceil(activeQuestions.length / 10);
  const currentChunkIndex = Math.floor(currentIndex / 10);
  const chunkStart = currentChunkIndex * 10;
  const chunkEnd = Math.min(activeQuestions.length, chunkStart + 10);

  // CONFIG SCREEN
  if (examState === 'config') {
    return (
      <div className="max-w-2xl mx-auto space-y-5 animate-fade-in">
        <div className="bg-[#131C31] border border-[#233252] rounded-2xl p-6 shadow-xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-bone-100">
                Simulador Oficial CNP (Optimizado TDAH)
              </h2>
              <p className="text-xs text-bone-400">
                Formato oficial de 3 opciones (A, B, C) con penalización real: 2 errores anulan 1 acierto.
              </p>
            </div>
          </div>

          <div className="space-y-4 pt-3 border-t border-[#233252]">
            {/* Length selector */}
            <div>
              <label className="text-xs font-semibold text-bone-300 block mb-2">
                Número de preguntas (Chunking adaptado a tu nivel de energía):
              </label>
              <div className="grid grid-cols-5 gap-2">
                {[10, 20, 30, 40, 50].map(count => (
                  <button
                    key={count}
                    onClick={() => setQuestionCount(count)}
                    className={`py-2.5 rounded-xl border font-bold text-xs transition-all ${
                      questionCount === count
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/60 shadow-sm shadow-emerald-500/20'
                        : 'bg-[#1A253F]/60 text-bone-400 border-[#233252] hover:text-bone-200'
                    }`}
                  >
                    {count} preg.
                  </button>
                ))}
              </div>
            </div>

            {/* Topic selector */}
            <div>
              <label className="text-xs font-semibold text-bone-300 block mb-1.5">
                Materia o Tema a evaluar:
              </label>
              <select
                value={selectedTopicId}
                onChange={(e) => setSelectedTopicId(e.target.value)}
                className="w-full bg-[#0B1120] border border-[#233252] rounded-xl px-3.5 py-2.5 text-xs text-bone-200 outline-none focus:border-emerald-500/60"
              >
                <option value="all">Todas las materias disponibles ({examQuestions.length} preguntas en total)</option>
                {topics.map(t => (
                  <option key={t.id} value={t.id}>{t.title}</option>
                ))}
              </select>
            </div>

            {/* Instant Feedback Toggle */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#0B1120]/60 border border-[#233252]">
              <div>
                <div className="text-xs font-semibold text-bone-200 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  Feedback Inmediato (Modo Aprendizaje TDAH)
                </div>
                <div className="text-[11px] text-bone-500">
                  Muestra la justificación al instante tras marcar. Desactívalo para un simulacro ciego estricto.
                </div>
              </div>
              <button
                onClick={() => setInstantFeedback(!instantFeedback)}
                className={`p-1 rounded-full transition-colors ${
                  instantFeedback ? 'text-emerald-400' : 'text-bone-500'
                }`}
              >
                {instantFeedback ? <ToggleRight className="w-8 h-8" /> : <ToggleLeft className="w-8 h-8" />}
              </button>
            </div>

            {/* Official Formula Badge */}
            <div className="p-3 rounded-xl bg-[#1A253F]/40 border border-[#233252] text-[11px] text-bone-400 font-mono">
              <span className="text-emerald-400 font-bold">Fórmula CNP:</span> [Aciertos - (Errores / 2)] × (10 / Total). Las preguntas sin contestar no penalizan.
            </div>

            {/* Start Button */}
            <button
              onClick={handleStartExam}
              className="w-full py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold text-sm transition-all shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2"
            >
              <span>Comenzar Examen</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // TAKING EXAM SCREEN
  if (examState === 'taking') {
    const currentQ = activeQuestions[currentIndex];
    const userAnswer = answers[currentQ.id];
    const hasAnswered = userAnswer !== undefined;
    const isCorrect = hasAnswered && userAnswer === currentQ.correctIndex;

    return (
      <div className="max-w-3xl mx-auto space-y-4 animate-fade-in">
        {/* Top Header & Chunking navigation */}
        <div className="bg-[#131C31] border border-[#233252] rounded-2xl p-4 shadow-xl">
          {/* Chunking Stepper */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-[#233252]">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                Bloque {currentChunkIndex + 1} de {totalChunks}
              </span>
              <span className="text-xs text-bone-400">
                (Preguntas {chunkStart + 1} a {chunkEnd})
              </span>
            </div>

            {/* Finish Button */}
            <button
              onClick={handleFinishExam}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 font-bold text-xs transition-all"
            >
              Entregar Examen
            </button>
          </div>

          {/* Question Index Pills within current chunk */}
          <div className="flex flex-wrap gap-1.5 pt-3">
            {activeQuestions.slice(chunkStart, chunkEnd).map((q, idx) => {
              const globalIdx = chunkStart + idx;
              const isCurrent = globalIdx === currentIndex;
              const answered = answers[q.id] !== undefined;

              return (
                <button
                  key={q.id}
                  onClick={() => setCurrentIndex(globalIdx)}
                  className={`w-7 h-7 rounded-lg text-xs font-mono font-bold transition-all ${
                    isCurrent
                      ? 'ring-2 ring-emerald-400 bg-emerald-500 text-slate-950'
                      : answered
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-[#1A253F] text-bone-400 hover:text-bone-200'
                  }`}
                >
                  {globalIdx + 1}
                </button>
              );
            })}
          </div>
        </div>

        {/* Current Question Card */}
        <div className="bg-[#131C31] border border-[#233252] rounded-2xl p-6 sm:p-7 shadow-xl">
          <div className="flex items-center justify-between text-xs text-bone-500 mb-3">
            <span>Pregunta {currentIndex + 1} de {activeQuestions.length}</span>
            {hasAnswered && (
              <button
                onClick={() => handleClearAnswer(currentQ.id)}
                className="text-[11px] text-bone-400 hover:text-amber-400 transition-colors"
              >
                Dejar en blanco
              </button>
            )}
          </div>

          <h3 className="text-base sm:text-lg font-bold text-bone-100 leading-relaxed mb-6">
            {currentQ.question}
          </h3>

          {/* Options (Strictly 3 CNP options: A, B, C) */}
          <div className="space-y-3 mb-6">
            {currentQ.options.map((opt, optIdx) => {
              const isSelected = userAnswer === optIdx;
              
              // Immediate feedback color logic (ADHD anti-cortisol: Amber for mistake, NEVER RED!)
              let optionStyle = 'bg-[#1A253F]/60 border-[#233252] text-bone-200 hover:border-[#32456C] hover:bg-[#1A253F]';

              if (instantFeedback && hasAnswered) {
                if (optIdx === currentQ.correctIndex) {
                  optionStyle = 'bg-emerald-500/20 border-emerald-500 text-emerald-200 font-semibold';
                } else if (isSelected && !isCorrect) {
                  optionStyle = 'bg-amber-500/20 border-amber-500 text-amber-200';
                } else {
                  optionStyle = 'bg-[#10172A]/40 border-[#233252]/40 text-bone-500';
                }
              } else if (isSelected) {
                optionStyle = 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-semibold';
              }

              return (
                <button
                  key={optIdx}
                  onClick={() => handleSelectOption(currentQ.id, optIdx)}
                  className={`w-full text-left p-4 rounded-xl border transition-all text-xs sm:text-sm flex items-start gap-3 ${optionStyle}`}
                >
                  <span className="font-mono font-bold mt-0.5">
                    {['A', 'B', 'C'][optIdx]})
                  </span>
                  <span className="flex-1">{opt.replace(/^[A-C]\)\s*/, '')}</span>
                </button>
              );
            })}
          </div>

          {/* Immediate Feedback Justification Box */}
          {instantFeedback && hasAnswered && (
            <div className={`p-4 rounded-xl border animate-fade-in ${
              isCorrect
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
            }`}>
              <div className="flex items-center gap-2 font-bold text-xs mb-1">
                {isCorrect ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>¡Correcto! Respuesta acertada (+1)</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 text-amber-400" />
                    <span>Fallo de examen (-0.5). Justificación oficial:</span>
                  </>
                )}
              </div>
              <p className="text-xs text-bone-300 mt-1 leading-relaxed">
                {currentQ.justification}
              </p>
            </div>
          )}

          {/* Footer Navigation */}
          <div className="flex items-center justify-between pt-5 mt-4 border-t border-[#233252]">
            <button
              onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
              disabled={currentIndex === 0}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1A253F] hover:bg-[#233252] disabled:opacity-40 disabled:cursor-not-allowed text-bone-300 text-xs font-semibold transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Anterior</span>
            </button>

            {currentIndex + 1 < activeQuestions.length ? (
              <button
                onClick={() => setCurrentIndex(prev => prev + 1)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-bold transition-all"
              >
                <span>Siguiente</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleFinishExam}
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-extrabold transition-all shadow-md shadow-emerald-500/20"
              >
                Finalizar Examen
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // RESULTS SCREEN
  if (examState === 'results' && examResult) {
    return (
      <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
        {/* Banner with Official Score */}
        <div className={`p-6 sm:p-8 rounded-2xl border shadow-2xl text-center ${
          examResult.isApto
            ? 'bg-emerald-500/10 border-emerald-500/40 text-bone-100'
            : 'bg-amber-500/10 border-amber-500/40 text-bone-100'
        }`}>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#131C31] border border-[#233252] text-xs font-semibold mb-3">
            <FileCheck className="w-4 h-4 text-emerald-400" />
            <span>Resultado Oficial Oposición CNP</span>
          </div>

          <div className="font-mono text-5xl sm:text-6xl font-black mb-2">
            <span className={examResult.isApto ? 'text-emerald-400' : 'text-amber-400'}>
              {examResult.score.toFixed(2)}
            </span>
            <span className="text-xl text-bone-500 font-normal"> / 10.00</span>
          </div>

          <div className={`text-base font-extrabold uppercase tracking-widest mb-4 ${
            examResult.isApto ? 'text-emerald-400' : 'text-amber-400'
          }`}>
            {examResult.isApto ? '¡APTO! (Superas la nota de corte 5.00)' : 'NO APTO (Nota de corte: 5.00)'}
          </div>

          {/* Breakdown cards */}
          <div className="grid grid-cols-3 gap-3 max-w-md mx-auto text-xs">
            <div className="p-2.5 rounded-xl bg-[#131C31] border border-emerald-500/30">
              <div className="font-mono font-bold text-lg text-emerald-400">+{examResult.rights}</div>
              <div className="text-bone-400 text-[11px]">Aciertos (+1.0)</div>
            </div>
            <div className="p-2.5 rounded-xl bg-[#131C31] border border-amber-500/30">
              <div className="font-mono font-bold text-lg text-amber-400">-{examResult.wrongs}</div>
              <div className="text-bone-400 text-[11px]">Errores (-0.5)</div>
            </div>
            <div className="p-2.5 rounded-xl bg-[#131C31] border border-[#233252]">
              <div className="font-mono font-bold text-lg text-bone-300">{examResult.blanks}</div>
              <div className="text-bone-400 text-[11px]">Blancas (0.0)</div>
            </div>
          </div>
        </div>

        {/* ADHD Dopamine Feature: Convert mistakes to flashcards! */}
        {examResult.mistakes.length > 0 && (
          <div className="p-5 rounded-2xl bg-[#131C31] border border-amber-500/40 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl bg-amber-500/15 text-amber-400">
                <BookmarkPlus className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-bone-100">
                  Transformar Fallos en Flashcards de Repaso
                </h4>
                <p className="text-xs text-bone-400">
                  Crea al instante un mazo con tus {examResult.mistakes.length} fallos para fijarlos en memoria a largo plazo.
                </p>
              </div>
            </div>

            <button
              onClick={handleConvertMistakes}
              disabled={convertedFlashcardsDone}
              className={`px-4 py-2.5 rounded-xl font-bold text-xs transition-all whitespace-nowrap ${
                convertedFlashcardsDone
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 cursor-default'
                  : 'bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-md shadow-amber-500/20'
              }`}
            >
              {convertedFlashcardsDone ? '✓ Flashcards Creadas' : `Crear ${examResult.mistakes.length} Flashcards`}
            </button>
          </div>
        )}

        {/* Detailed Review of All Questions */}
        <div className="bg-[#131C31] border border-[#233252] rounded-2xl p-5 shadow-xl">
          <h4 className="text-sm font-bold text-bone-100 mb-4 flex items-center justify-between">
            <span>Revisión Detallada del Examen</span>
            <span className="text-xs text-bone-500 font-normal">Fórmula CNP aplicada</span>
          </h4>

          <div className="space-y-4">
            {activeQuestions.map((q, idx) => {
              const ans = answers[q.id];
              const isBlank = ans === undefined;
              const isRight = ans === q.correctIndex;

              return (
                <div
                  key={q.id}
                  className={`p-4 rounded-xl border text-xs leading-relaxed ${
                    isBlank
                      ? 'bg-[#10172A]/50 border-[#233252]/50'
                      : isRight
                      ? 'bg-emerald-500/10 border-emerald-500/30'
                      : 'bg-amber-500/10 border-amber-500/30'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold mb-2">
                    <span className="text-bone-200">Pregunta {idx + 1}</span>
                    <span className={isRight ? 'text-emerald-400' : isBlank ? 'text-bone-400' : 'text-amber-400'}>
                      {isRight ? '+1.0 Acierto' : isBlank ? '0.0 En blanco' : '-0.5 Error'}
                    </span>
                  </div>

                  <p className="font-semibold text-bone-100 mb-2">{q.question}</p>

                  <div className="space-y-1 mb-2">
                    <div className="text-emerald-300 font-medium">
                      ✓ Correcta: {q.options[q.correctIndex]}
                    </div>
                    {!isRight && !isBlank && (
                      <div className="text-amber-300">
                        ✗ Tu respuesta: {q.options[ans]}
                      </div>
                    )}
                  </div>

                  <div className="text-bone-400 text-[11px] pt-2 border-t border-[#233252]/60">
                    <span className="font-semibold text-bone-300">Justificación:</span> {q.justification}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-6 flex justify-center">
            <button
              onClick={() => setExamState('config')}
              className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs transition-all"
            >
              Realizar Otro Simulacro
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
