import React, { useState, useEffect, useCallback } from 'react';
import { 
  RotateCw, 
  Lightbulb, 
  Check, 
  AlertCircle, 
  HelpCircle, 
  Sparkles, 
  Filter, 
  BookOpen, 
  Layers, 
  Award,
  ChevronLeft,
  ChevronRight,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { neuroAudio } from '../services/audioService';

export default function FlashcardsView({
  flashcards,
  topics,
  onUpdateStatus,
}) {
  const [selectedTopicId, setSelectedTopicId] = useState('all');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [showMnemonic, setShowMnemonic] = useState(false);
  const [sessionCompleted, setSessionCompleted] = useState(false);
  const [sessionStats, setSessionStats] = useState({ hard: 0, doubt: 0, mastered: 0 });

  // Filter cards by topic
  const filteredCards = flashcards.filter(c => {
    if (selectedTopicId === 'all') return true;
    return c.topicId === selectedTopicId;
  });

  const currentCard = filteredCards[currentIndex] || null;

  // Reset when topic changes
  useEffect(() => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setShowMnemonic(false);
    setSessionCompleted(false);
    setSessionStats({ hard: 0, doubt: 0, mastered: 0 });
  }, [selectedTopicId]);

  const handleFlip = useCallback(() => {
    setIsFlipped(prev => !prev);
  }, []);

  const handleRateCard = useCallback((status) => {
    if (!currentCard) return;

    // Sound effect
    if (status === 'mastered') {
      neuroAudio.playCorrectSound();
      setSessionStats(prev => ({ ...prev, mastered: prev.mastered + 1 }));
    } else if (status === 'doubt') {
      neuroAudio.playCorrectSound();
      setSessionStats(prev => ({ ...prev, doubt: prev.doubt + 1 }));
    } else {
      neuroAudio.playIncorrectSound();
      setSessionStats(prev => ({ ...prev, hard: prev.hard + 1 }));
    }

    onUpdateStatus(currentCard.id, status);

    // Advance to next card or complete
    if (currentIndex + 1 < filteredCards.length) {
      setIsFlipped(false);
      setShowMnemonic(false);
      setCurrentIndex(prev => prev + 1);
    } else {
      setSessionCompleted(true);
      neuroAudio.playCompletionCelebration();
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#10B981', '#34D399', '#F59E0B']
      });
    }
  }, [currentCard, currentIndex, filteredCards.length, onUpdateStatus]);

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Do not capture if user is typing in an input/textarea
      if (['INPUT', 'TEXTAREA'].includes(e.target.tagName)) return;

      if (e.code === 'Space' || e.key === ' ') {
        e.preventDefault();
        handleFlip();
      } else if (e.key === '1') {
        e.preventDefault();
        handleRateCard('hard');
      } else if (e.key === '2') {
        e.preventDefault();
        handleRateCard('doubt');
      } else if (e.key === '3') {
        e.preventDefault();
        handleRateCard('mastered');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleFlip, handleRateCard]);

  const restartDeck = () => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setShowMnemonic(false);
    setSessionCompleted(false);
    setSessionStats({ hard: 0, doubt: 0, mastered: 0 });
  };

  if (filteredCards.length === 0) {
    return (
      <div className="bg-[#131C31] border border-[#233252] rounded-2xl p-8 text-center max-w-xl mx-auto my-6">
        <BookOpen className="w-12 h-12 text-emerald-400/60 mx-auto mb-3" />
        <h3 className="text-base font-bold text-bone-100 mb-2">No hay flashcards para este tema</h3>
        <p className="text-xs text-bone-400 mb-4">
          Selecciona otro tema o ve al módulo de temario para subir un PDF o imagen y generarlas con IA.
        </p>
        <button
          onClick={() => setSelectedTopicId('all')}
          className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs"
        >
          Ver todas las flashcards
        </button>
      </div>
    );
  }

  // Completion Screen
  if (sessionCompleted) {
    return (
      <div className="max-w-xl mx-auto bg-[#131C31] border border-emerald-500/40 rounded-2xl p-6 sm:p-8 text-center my-6 shadow-2xl animate-fade-in">
        <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto mb-4 text-emerald-400">
          <Award className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-extrabold text-bone-100 mb-2">
          ¡Mazo Completado con Éxito!
        </h2>
        <p className="text-xs text-bone-400 mb-6 max-w-md mx-auto">
          Excelente sesión de memoria activa. Has reforzado conexiones neuronales clave para la oposición.
        </p>

        {/* Stats grid */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30">
            <div className="font-mono text-2xl font-black text-emerald-400">{sessionStats.mastered}</div>
            <div className="text-[11px] font-medium text-emerald-300">Dominadas</div>
          </div>
          <div className="p-3 rounded-xl bg-amber-500/15 border border-amber-500/30">
            <div className="font-mono text-2xl font-black text-amber-300">{sessionStats.doubt}</div>
            <div className="text-[11px] font-medium text-amber-300">Con Duda</div>
          </div>
          <div className="p-3 rounded-xl bg-amber-600/15 border border-amber-600/30">
            <div className="font-mono text-2xl font-black text-amber-400">{sessionStats.hard}</div>
            <div className="text-[11px] font-medium text-amber-400">Para Repasar</div>
          </div>
        </div>

        <button
          onClick={restartDeck}
          className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold text-xs transition-all shadow-lg shadow-emerald-500/20"
        >
          Repasar Mazo de Nuevo
        </button>
      </div>
    );
  }

  const topicName = topics.find(t => t.id === currentCard.topicId)?.title || 'Temario CNP';

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      {/* Top Controls & Filter */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#131C31] p-3 rounded-2xl border border-[#233252]">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-emerald-400" />
          <select
            value={selectedTopicId}
            onChange={(e) => setSelectedTopicId(e.target.value)}
            className="bg-[#0B1120] border border-[#233252] rounded-xl px-3 py-1.5 text-xs text-bone-200 outline-none focus:border-emerald-500/60"
          >
            <option value="all">Todos los temas ({flashcards.length} tarjetas)</option>
            {topics.map(t => (
              <option key={t.id} value={t.id}>{t.title}</option>
            ))}
          </select>
        </div>

        {/* Counter and Progress */}
        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
          <span className="text-xs font-mono text-bone-400">
            Tarjeta <span className="font-bold text-bone-100">{currentIndex + 1}</span> de <span className="font-bold text-bone-100">{filteredCards.length}</span>
          </span>
          <div className="w-24 bg-[#1A253F] h-2 rounded-full overflow-hidden">
            <div 
              className="bg-emerald-500 h-full transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / filteredCards.length) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* 3D Flashcard Container */}
      <div className="perspective-1000 min-h-[340px] select-none">
        <div 
          onClick={handleFlip}
          className={`relative w-full min-h-[340px] cursor-pointer transition-transform duration-500 transform-style-3d ${
            isFlipped ? 'rotate-y-180' : ''
          }`}
        >
          {/* FRONT SIDE */}
          <div className="absolute inset-0 w-full h-full bg-[#131C31] border border-[#233252] hover:border-emerald-500/40 rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-xl backface-hidden transition-all">
            <div>
              <div className="flex items-center justify-between gap-2 mb-4">
                <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2.5 py-1 rounded-lg">
                  {topicName}
                </span>
                <span className="text-[10px] text-bone-500 font-mono">
                  Presiona [Espacio] o haz clic para girar
                </span>
              </div>

              <h3 className="text-base sm:text-lg font-bold text-bone-100 leading-relaxed mt-2">
                {currentCard.question}
              </h3>
            </div>

            {/* Mnemonic Hint Drawer on Front */}
            <div>
              {currentCard.mnemonicClue && (
                <div 
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowMnemonic(!showMnemonic);
                  }}
                  className="mt-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs transition-all hover:bg-amber-500/15"
                >
                  <div className="flex items-center justify-between font-semibold">
                    <span className="flex items-center gap-1.5">
                      <Lightbulb className="w-4 h-4 text-amber-400" />
                      Pista Mnemotécnica TDAH
                    </span>
                    <span className="text-[10px] uppercase text-amber-400/80">
                      {showMnemonic ? 'Ocultar' : 'Ver Pista'}
                    </span>
                  </div>
                  {showMnemonic && (
                    <p className="mt-2 text-bone-200 text-xs font-normal border-t border-amber-500/20 pt-2 animate-fade-in">
                      {currentCard.mnemonicClue}
                    </p>
                  )}
                </div>
              )}

              <div className="mt-4 pt-3 border-t border-[#233252] flex items-center justify-between text-bone-500 text-xs">
                <span>Girar tarjeta</span>
                <RotateCw className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* BACK SIDE */}
          <div className="absolute inset-0 w-full h-full bg-[#10172A] border border-emerald-500/40 rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-2xl backface-hidden rotate-y-180">
            <div>
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-500/15 px-2.5 py-1 rounded-lg">
                  Respuesta Oficial
                </span>
                {currentCard.reference && (
                  <span className="text-[11px] text-bone-400 font-mono bg-[#1A253F] px-2 py-0.5 rounded">
                    {currentCard.reference}
                  </span>
                )}
              </div>

              <div className="text-sm sm:text-base text-bone-100 font-medium leading-relaxed whitespace-pre-line mt-2">
                {currentCard.answer}
              </div>

              {currentCard.mnemonicClue && (
                <div className="mt-4 p-2.5 rounded-xl bg-[#131C31] border border-[#233252] text-xs text-amber-300">
                  <span className="font-semibold flex items-center gap-1 mb-1 text-amber-400">
                    <Lightbulb className="w-3.5 h-3.5" /> Anclaje Nemotécnico:
                  </span>
                  <span className="text-bone-300">{currentCard.mnemonicClue}</span>
                </div>
              )}
            </div>

            <div className="text-center pt-3 border-t border-[#233252] text-bone-500 text-xs">
              Valora tu recuerdo abajo para continuar
            </div>
          </div>
        </div>
      </div>

      {/* SRS Rating Actions (Keys: 1, 2, 3) */}
      <div className="bg-[#131C31] p-3 rounded-2xl border border-[#233252] shadow-lg">
        <div className="text-xs text-bone-400 text-center mb-2 font-medium">
          ¿Cómo ha sido tu recuerdo? (Usa teclado: <kbd className="px-1.5 py-0.5 rounded bg-[#1A253F] text-bone-300 font-mono">1</kbd>, <kbd className="px-1.5 py-0.5 rounded bg-[#1A253F] text-bone-300 font-mono">2</kbd>, <kbd className="px-1.5 py-0.5 rounded bg-[#1A253F] text-bone-300 font-mono">3</kbd>)
        </div>

        <div className="grid grid-cols-3 gap-2.5">
          {/* 1: Hard / Repasar (Soft Amber, NEVER RED!) */}
          <button
            onClick={() => handleRateCard('hard')}
            className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold transition-all"
          >
            <AlertCircle className="w-4 h-4 text-amber-400" />
            <span>[1] Difícil</span>
          </button>

          {/* 2: Doubt / Duda */}
          <button
            onClick={() => handleRateCard('doubt')}
            className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-amber-400/10 hover:bg-amber-400/20 border border-amber-400/30 text-amber-200 text-xs font-bold transition-all"
          >
            <HelpCircle className="w-4 h-4 text-amber-300" />
            <span>[2] Duda</span>
          </button>

          {/* 3: Mastered / Dominada (Emerald) */}
          <button
            onClick={() => handleRateCard('mastered')}
            className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/50 text-emerald-300 text-xs font-bold transition-all shadow-sm shadow-emerald-500/10"
          >
            <Check className="w-4 h-4 text-emerald-400 stroke-[3]" />
            <span>[3] Dominada</span>
          </button>
        </div>
      </div>
    </div>
  );
}
