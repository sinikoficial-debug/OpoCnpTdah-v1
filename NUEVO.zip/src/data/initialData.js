// Initial realistic CNP opposition study material tailored for ADHD learning
export const INITIAL_TOPICS = [
  {
    id: 'cnp-topic-1',
    title: 'Tema 1: Constitución Española de 1978 (Principios y Derechos)',
    category: 'Ciencias Jurídicas',
    description: 'Título Preliminar, Derechos y Deberes Fundamentales (Art. 10 a 29), Garantías y Suspensión.',
    createdAt: new Date().toISOString(),
    flashcardCount: 8,
    examQuestionCount: 15,
  },
  {
    id: 'cnp-topic-2',
    title: 'Tema 8: Ley Orgánica 2/1986 de Fuerzas y Cuerpos de Seguridad',
    category: 'Ciencias Jurídicas',
    description: 'Principios básicos de actuación, funciones exclusivas del CNP, régimen estatutario y organización.',
    createdAt: new Date().toISOString(),
    flashcardCount: 8,
    examQuestionCount: 15,
  },
  {
    id: 'cnp-topic-3',
    title: 'Tema 10: Derecho Penal - Teoría General del Delito',
    category: 'Ciencias Jurídicas',
    description: 'Concepto de delito, dolo e imprudencia, eximentes (Art. 20 CP), atenuantes y agravantes.',
    createdAt: new Date().toISOString(),
    flashcardCount: 6,
    examQuestionCount: 12,
  }
];

export const INITIAL_FLASHCARDS = [
  // Tema 1: CE 1978
  {
    id: 'fc-1',
    topicId: 'cnp-topic-1',
    question: '¿Cuáles son los valores superiores del ordenamiento jurídico español según el Art. 1.1 CE?',
    answer: 'La libertad, la justicia, la igualdad y el pluralismo político.',
    mnemonicClue: 'Regla mnemotécnica: "LI-JU-IG-PLU" (Libertad, Justicia, Igualdad, Pluralismo). Piensa en "LIbro de JUsticia IGualitaria para el PUEBLO".',
    reference: 'Art. 1.1 Constitución Española',
    status: 'new', // 'new' | 'hard' | 'doubt' | 'mastered'
    reviews: 0,
    lastReviewed: null,
  },
  {
    id: 'fc-2',
    topicId: 'cnp-topic-1',
    question: '¿Cuál es el plazo máximo de la detención preventiva según el Art. 17.2 CE y cuándo debe pasar a disposición judicial?',
    answer: 'El plazo máximo legal es de 72 horas. Sin embargo, no podrá durar más del tiempo estrictamente necesario para la realización de las averiguaciones.',
    mnemonicClue: 'Mnemotecnia: "72 horas MÁXIMO, pero ni un minuto de más si las pesquisas acaban antes". Clave de trampa oficial de examen: No siempre son 72h obligatorias.',
    reference: 'Art. 17.2 CE y Art. 520 LECrim',
    status: 'new',
    reviews: 0,
    lastReviewed: null,
  },
  {
    id: 'fc-3',
    topicId: 'cnp-topic-1',
    question: '¿Qué mayorías exige la reforma ordinaria de la Constitución (Art. 167)?',
    answer: 'Aprobación por mayoría de 3/5 de cada una de las Cámaras (Congreso y Senado).',
    mnemonicClue: 'Mnemotecnia: "167 = 3/5". Tres quintos de ambas. Si no hay acuerdo, comisión mixta paritaria.',
    reference: 'Art. 167 CE',
    status: 'new',
    reviews: 0,
    lastReviewed: null,
  },
  {
    id: 'fc-4',
    topicId: 'cnp-topic-1',
    question: '¿Quién declara el Estado de Alarma y por qué plazo inicial?',
    answer: 'El Gobierno mediante Decreto acordado en Consejo de Ministros por un plazo máximo de 15 días, dando cuenta al Congreso.',
    mnemonicClue: 'Mnemotecnia: Alarma = "Gobierno 15 días". Excepción = "Gobierno con autorización previa del Congreso (30d)". Sitio = "Congreso por mayoría absoluta a propuesta del Gobierno".',
    reference: 'Art. 116 CE',
    status: 'new',
    reviews: 0,
    lastReviewed: null,
  },

  // Tema 8: LO 2/1986
  {
    id: 'fc-5',
    topicId: 'cnp-topic-2',
    question: '¿Cuáles son los 3 principios rectores de las Relaciones con la Comunidad en la LO 2/1986 (Art. 5.1)?',
    answer: 'a) Neutralidad política e imparcialidad.\nb) Integridad y dignidad.\nc) Sujeción y observancia de la legalidad.',
    mnemonicClue: 'Mnemotecnia TDAH: "N-I-L" (Neutralidad, Integridad, Legalidad). Los tres pilares éticos de la policía.',
    reference: 'Art. 5.1 Ley Orgánica 2/1986',
    status: 'new',
    reviews: 0,
    lastReviewed: null,
  },
  {
    id: 'fc-6',
    topicId: 'cnp-topic-2',
    question: '¿Cuándo pueden los miembros del CNP utilizar armas de fuego según la LO 2/1986 (Art. 5.2.c)?',
    answer: 'Solo en situaciones en que exista un riesgo racionalmente grave para su vida, su integridad física o las de terceras personas, o en aquellas circunstancias que puedan suponer un grave riesgo para la seguridad ciudadana y de conformidad con los principios de congruencia, oportunidad y proporcionalidad.',
    mnemonicClue: 'Mnemotecnia clave CNP: Regla "C-O-P" (Congruencia, Oportunidad, Proporcionalidad) + Riesgo racionalmente grave.',
    reference: 'Art. 5.2.c Ley Orgánica 2/1986',
    status: 'new',
    reviews: 0,
    lastReviewed: null,
  },
  {
    id: 'fc-7',
    topicId: 'cnp-topic-2',
    question: '¿Qué competencias son exclusivas del Cuerpo Nacional de Policía según el Art. 12 de la LO 2/1986?',
    answer: 'Extranjería, DNI y Pasaporte, Control de entrada/salida del territorio nacional, Juego, y Vigilancia e investigación de delitos de drogas y delincuencia organizada en ámbito interprovincial.',
    mnemonicClue: 'Mnemotecnia visual: "DOCUMENTO + FRONTERA + CASINO + DROGA SUPRAPROVINCIAL". La Guardia Civil lleva Armas, Tráfico y Resguardo Fiscal.',
    reference: 'Art. 12 Ley Orgánica 2/1986',
    status: 'new',
    reviews: 0,
    lastReviewed: null,
  },

  // Tema 10: Código Penal
  {
    id: 'fc-8',
    topicId: 'cnp-topic-3',
    question: '¿Qué es el dolo en Derecho Penal y cómo se clasifica comúnmente?',
    answer: 'Conocimiento y voluntad de realizar los elementos del tipo objetivo. Se clasifica en: Dolo directo de 1er grado (intención directa), Dolo de 2º grado (consecuencias necesarias) y Dolo eventual (asume el resultado como probable).',
    mnemonicClue: 'Mnemotecnia: Dolo = "Sé lo que hago + Quiero hacerlo". El dolo eventual es: "Aunque no lo busque, si pasa, me da igual".',
    reference: 'Art. 5 y 10 Código Penal',
    status: 'new',
    reviews: 0,
    lastReviewed: null,
  },
  {
    id: 'fc-9',
    topicId: 'cnp-topic-3',
    question: '¿Cuáles son los requisitos de la Legítima Defensa como eximente (Art. 20.4 CP)?',
    answer: '1. Agresión ilegítima (requisito esencial ineludible).\n2. Necesidad racional del medio empleado para impedirla o repelerla.\n3. Falta de provocación suficiente por parte del defensor.',
    mnemonicClue: 'Mnemotecnia TDAH: "A-N-F" (Agresión, Necesidad racional, Falta de provocación). Si no hay agresión previa, NUNCA cabe legítima defensa.',
    reference: 'Art. 20.4 Código Penal',
    status: 'new',
    reviews: 0,
    lastReviewed: null,
  }
];

export const INITIAL_EXAM_QUESTIONS = [
  {
    id: 'eq-1',
    topicId: 'cnp-topic-1',
    question: 'Según el artículo 1.2 de la Constitución Española, ¿en quién reside la soberanía nacional?',
    options: [
      'A) En las Cortes Generales, como representantes legítimos del pueblo.',
      'B) En el pueblo español, del que emanan los poderes del Estado.',
      'C) En la Corona, como símbolo de la unidad y permanencia del Estado.'
    ],
    correctIndex: 1,
    justification: 'El Art. 1.2 CE establece textualmente: "La soberanía nacional reside en el pueblo español, del que emanan los poderes del Estado".'
  },
  {
    id: 'eq-2',
    topicId: 'cnp-topic-1',
    question: 'El procedimiento de Habeas Corpus regulado en el artículo 17.4 de la Constitución persigue:',
    options: [
      'A) La inmediata puesta a disposición judicial de toda persona detenida ilegalmente.',
      'B) La puesta en libertad provisional inmediata sin cargos.',
      'C) La suspensión del plazo de las 72 horas por razones de terrorismo.'
    ],
    correctIndex: 0,
    justification: 'El Art. 17.4 CE dispone que la ley regulará un procedimiento de "habeas corpus" para producir la inmediata puesta a disposición judicial de toda persona ilegalmente detenida.'
  },
  {
    id: 'eq-3',
    topicId: 'cnp-topic-1',
    question: '¿Qué derecho NO puede ser suspendido tras la declaración del estado de excepción?',
    options: [
      'A) El derecho al secreto de las comunicaciones (Art. 18.3).',
      'B) El derecho a la inviolabilidad del domicilio (Art. 18.2).',
      'C) El derecho a ser informado de los derechos y razones de la detención (Art. 17.3).'
    ],
    correctIndex: 2,
    justification: 'El Art. 55.1 CE permite suspender el Art. 17.1 y 17.2, pero NO el 17.3 (derecho a ser informado y asistencia de letrado), garantizando la integridad del detenido.'
  },
  {
    id: 'eq-4',
    topicId: 'cnp-topic-1',
    question: 'La forma política del Estado español según la Constitución de 1978 es:',
    options: [
      'A) Monarquía parlamentaria.',
      'B) Estado social y democrático de Derecho.',
      'C) República constitucional descentralizada.'
    ],
    correctIndex: 0,
    justification: 'El Art. 1.3 CE define explícitamente: "La forma política del Estado español es la Monarquía parlamentaria".'
  },
  {
    id: 'eq-5',
    topicId: 'cnp-topic-1',
    question: '¿Qué mayoría se requiere en el Congreso para investir al Presidente del Gobierno en primera votación?',
    options: [
      'A) Mayoría simple de los presentes.',
      'B) Mayoría absoluta de sus miembros.',
      'C) Mayoría de tres quintos de los diputados.'
    ],
    correctIndex: 1,
    justification: 'El Art. 99.3 CE exige mayoría absoluta en la primera votación. De no alcanzarse, se vota a las 48 horas requiriéndose solo mayoría simple.'
  },

  // Tema 8: LO 2/1986
  {
    id: 'eq-6',
    topicId: 'cnp-topic-2',
    question: 'Según el artículo 5.2 de la Ley Orgánica 2/1986, en el ejercicio de sus funciones los miembros de las FFCCS actuarán con:',
    options: [
      'A) Absoluta neutralidad ideológica pero sometimiento al criterio de oportunidad política.',
      'B) Absoluta neutralidad política y sindical en sus intervenciones armadas únicamente.',
      'C) Absoluta neutralidad política e imparcialidad y, en consecuencia, sin discriminación alguna.'
    ],
    correctIndex: 2,
    justification: 'El Art. 5.1.a de la LO 2/1986 establece como principio básico de actuación actuar con absoluta neutralidad política e imparcialidad y sin discriminación.'
  },
  {
    id: 'eq-7',
    topicId: 'cnp-topic-2',
    question: '¿Cuál de las siguientes materias es competencia EXCLUSIVA del Cuerpo Nacional de Policía?',
    options: [
      'A) La expedición del DNI y pasaportes, y el control de entrada y salida del territorio nacional.',
      'B) La vigilancia del tráfico en vías interurbanas salvo en CCAA transferidas.',
      'C) El control de armas y explosivos.'
    ],
    correctIndex: 0,
    justification: 'El Art. 12.1.A de la LO 2/1986 otorga con carácter exclusivo al CNP la expedición de DNI, pasaportes, control de extranjería y fronteras. Armas y tráfico son de la Guardia Civil.'
  },
  {
    id: 'eq-8',
    topicId: 'cnp-topic-2',
    question: 'La obediencia debida en la LO 2/1986 exonera a un funcionario de policía de responsabilidad cuando:',
    options: [
      'A) Cumple una orden que constituya manifiestamente delito.',
      'B) En ningún caso cuando la orden entrañe la ejecución de actos que manifiestamente constituyan delito o sean contrarios a las Leyes.',
      'C) Siempre que la orden haya sido formulada por escrito por un superior jerárquico.'
    ],
    correctIndex: 1,
    justification: 'Art. 5.1.d LO 2/1986: "En ningún caso, la obediencia debida podrá amparar órdenes que entrañen la ejecución de actos que manifiestamente constituyan delito o sean contrarios a las Leyes".'
  },
  {
    id: 'eq-9',
    topicId: 'cnp-topic-2',
    question: 'Los miembros del CNP, respecto a su jornada de trabajo y disponibilidad horaria:',
    options: [
      'A) Tienen dedicación exclusiva y deben intervenir en cualquier momento y lugar, estando o no de servicio, en defensa de la Ley.',
      'B) Solo están obligados a intervenir fuera de servicio si portan el arma reglamentaria.',
      'C) Su jornada laboral está estrictamente acotada a 37,5 horas semanales sin disponibilidad sobrevenida.'
    ],
    correctIndex: 0,
    justification: 'Art. 5.4 LO 2/1986: Principio de Dedicación Profesional. Deberán llevar a cabo sus funciones con total dedicación, debiendo intervenir siempre, en cualquier tiempo y lugar, se hallen o no de servicio.'
  },
  {
    id: 'eq-10',
    topicId: 'cnp-topic-2',
    question: 'El uso de la fuerza por los miembros de las Fuerzas y Cuerpos de Seguridad debe regirse estrictamente por los principios de:',
    options: [
      'A) Congruencia, oportunidad y proporcionalidad en la utilización de los medios a su alcance.',
      'B) Autoridad, celeridad y disuasión contundente.',
      'C) Inmediatez, necesidad imperativa y eficacia policial.'
    ],
    correctIndex: 0,
    justification: 'Art. 5.2.c LO 2/1986: En el ejercicio de sus funciones deberán actuar con la decisión necesaria y sin demora cuando de ello dependa evitar un daño grave, rigiéndose por los principios de congruencia, oportunidad y proporcionalidad.'
  },

  // Tema 10: Código Penal
  {
    id: 'eq-11',
    topicId: 'cnp-topic-3',
    question: 'Conforme al artículo 10 del Código Penal, son delitos:',
    options: [
      'A) Las acciones u omisiones dolosas o imprudentes penadas por la ley.',
      'B) Las infracciones cometidas con premeditación o alevosía manifiesta.',
      'C) Los hechos típicos, antijurídicos y culpables sancionados administrativamente.'
    ],
    correctIndex: 0,
    justification: 'El Art. 10 CP reza literalmente: "Son delitos las acciones y omisiones dolosas o imprudentes penadas por la ley".'
  },
  {
    id: 'eq-12',
    topicId: 'cnp-topic-3',
    question: '¿Cuál de los siguientes requisitos NO es exigido legalmente para la eximente de Legítima Defensa (Art. 20.4 CP)?',
    options: [
      'A) Agresión ilegítima previa o inminente.',
      'B) Proporcionalidad geométrica estricta de las armas empleadas.',
      'C) Falta de provocación suficiente por parte del defensor.'
    ],
    correctIndex: 1,
    justification: 'La ley exige "necesidad racional del medio empleado", no una igualdad milimétrica o geométrica de armas, sino adecuación racional según las circunstancias.'
  },
  {
    id: 'eq-13',
    topicId: 'cnp-topic-3',
    question: 'El que obrare impulsado por estado de necesidad (Art. 20.5 CP), para quedar exento de pena precisa que:',
    options: [
      'A) El mal causado no sea mayor que el que se trate de evitar.',
      'B) La situación de necesidad haya sido provocada voluntariamente por el sujeto activo.',
      'C) Exista siempre agresión ilegítima por parte del perjudicado.'
    ],
    correctIndex: 0,
    justification: 'Art. 20.5 CP: Primer requisito: Que el mal causado no sea mayor que el que se trate de evitar, y que la situación no haya sido provocada intencionadamente por el sujeto.'
  },
  {
    id: 'eq-14',
    topicId: 'cnp-topic-3',
    question: 'Las medidas de seguridad en el Código Penal español se fundamentan en:',
    options: [
      'A) La culpabilidad del reo y el daño económico causado.',
      'B) La peligrosidad criminal del sujeto exteriorizada en un hecho delictivo previo.',
      'C) La gravedad intrínseca del delito cometido.'
    ],
    correctIndex: 1,
    justification: 'Art. 6.1 CP: "Las medidas de seguridad se fundamentan en la peligrosidad criminal del sujeto al que se impongan, exteriorizada en la comisión de un hecho previsto como delito".'
  },
  {
    id: 'eq-15',
    topicId: 'cnp-topic-3',
    question: '¿Cuándo es punible la conspiración y la proposición para delinquir según el artículo 17 del Código Penal?',
    options: [
      'A) Con carácter general en todos los delitos del Código Penal.',
      'B) Únicamente en los casos especialmente previstos en la ley.',
      'C) Solo cuando se inicien actos materiales de ejecución directa.'
    ],
    correctIndex: 1,
    justification: 'Art. 17.3 CP: "La conspiración y la proposición para delinquir sólo se castigarán en los casos especialmente previstos en la ley" (ej. homicidio, terrorismo, rebelión).'
  }
];

export const INITIAL_DISTRACTIONS = [
  {
    id: 'dist-1',
    text: 'Revisar fecha de publicación de la lista definitiva en el BOE',
    timestamp: new Date(Date.now() - 3600000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    completed: false
  },
  {
    id: 'dist-2',
    text: 'Comprar bolígrafos de tinta negra de repuesto para el simulacro',
    timestamp: new Date(Date.now() - 7200000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    completed: true
  }
];
